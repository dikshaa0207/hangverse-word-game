import { Link, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { Coins, Flame, Home } from "lucide-react";
import { Doodle } from "@/components/hangverse/Doodle";
import { useHangVerse } from "@/lib/hangverse/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/play", label: "Play" },
  { to: "/statistics", label: "Stats" },
  { to: "/achievements", label: "Achievements" },
  { to: "/library", label: "Library" },
  { to: "/history", label: "History" },
  { to: "/profile", label: "Profile" },
] as const;

export function PageShell({
  children,
  title,
  subtitle,
}: {
  children: ReactNode;
  title?: string;
  subtitle?: string;
}) {
  const { state, hydrated } = useHangVerse();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-border/60 glass">
        <div className="mx-auto grid max-w-6xl grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3 sm:px-6">
          <Link to="/" className="flex min-w-0 items-center gap-2 press">
            <span className="grid size-9 shrink-0 place-items-center rounded-2xl bg-primary text-lg text-primary-foreground shadow-sm">
              H
            </span>
            <span className="truncate font-display text-lg font-bold">HangVerse</span>
          </Link>
          <div className="flex items-center gap-2">
            <span className="hidden items-center gap-1 rounded-full bg-warning/25 px-3 py-1 text-sm font-bold text-warning-foreground sm:inline-flex">
              <Coins className="size-4" aria-hidden /> {hydrated ? state.coins : 0}
            </span>
            <span className="hidden items-center gap-1 rounded-full bg-destructive/15 px-3 py-1 text-sm font-bold text-destructive sm:inline-flex">
              <Flame className="size-4" aria-hidden /> {hydrated ? state.currentStreak : 0}
            </span>
            <Link
              to="/"
              className="grid size-9 place-items-center rounded-full bg-secondary text-secondary-foreground press"
              aria-label="Back to home"
            >
              <Home className="size-4" aria-hidden />
            </Link>
          </div>
        </div>
        <nav className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4 pb-2 sm:px-6">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "shrink-0 rounded-full px-3 py-1.5 text-sm font-semibold transition-colors",
                pathname === item.to
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-secondary hover:text-secondary-foreground",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </header>

      <main className="mx-auto w-full max-w-6xl px-4 py-8 sm:px-6">
        {title ? (
          <div className="relative mb-6 animate-rise">
            <Doodle
              name="star"
              size={26}
              strokeWidth={2.2}
              className="absolute -left-6 -top-3 hidden text-warning/70 sm:block"
            />
            <h1 className="font-display text-3xl font-extrabold sm:text-4xl">{title}</h1>
            {subtitle ? <p className="hand text-2xl text-muted-foreground">{subtitle}</p> : null}
          </div>
        ) : null}
        {children}
      </main>

      <footer className="mx-auto flex max-w-6xl flex-col items-center gap-1 px-4 pb-10 text-center sm:px-6">
        <Doodle name="squiggle" size={64} strokeWidth={2} className="text-primary/25" />
        <p className="hand text-xl text-muted-foreground">HangVerse — Guess. Learn. Achieve. ✦</p>
      </footer>
    </div>
  );
}
