import type { CSSProperties, ReactNode } from "react";
import { cn } from "@/lib/utils";

export type DoodleName =
  | "star"
  | "heart"
  | "cloud"
  | "flower"
  | "sparkle"
  | "arrow"
  | "smiley"
  | "bulb"
  | "pencil"
  | "book"
  | "crown"
  | "check"
  | "bubble"
  | "squiggle";

const PATHS: Record<DoodleName, ReactNode> = {
  star: (
    <path d="M24 5 L28.5 18.5 L42 20.5 L32 30 L34.5 43.5 L24 37 L13.5 43.5 L16 30 L6 20.5 L19.5 18.5 Z" />
  ),
  heart: (
    <path d="M24 41C14 34 7 28 7 20.5 7 14.5 11.5 10 17 10c3.4 0 6 1.8 7 4 1-2.2 3.6-4 7-4 5.5 0 10 4.5 10 10.5C41 28 34 34 24 41Z" />
  ),
  cloud: (
    <path d="M13 33c-4 0-7-2.8-7-6.4 0-3.4 2.7-6.2 6.3-6.4C13.4 15.6 17.6 12 22.7 12c5.4 0 9.8 3.9 10.6 9 4 .3 7.7 3 7.7 6.4 0 3.4-3.3 5.6-7.4 5.6H13Z" />
  ),
  flower: (
    <>
      <circle cx="24" cy="17" r="6" />
      <circle cx="15" cy="24" r="6" />
      <circle cx="33" cy="24" r="6" />
      <circle cx="19" cy="34" r="6" />
      <circle cx="29" cy="34" r="6" />
      <circle cx="24" cy="26" r="3.4" />
    </>
  ),
  sparkle: (
    <>
      <path d="M24 6c1.5 9.5 4.5 12.5 14 14-9.5 1.5-12.5 4.5-14 14-1.5-9.5-4.5-12.5-14-14 9.5-1.5 12.5-4.5 14-14Z" />
      <path d="M39 32c.7 4.2 2 5.5 6.2 6.2-4.2.7-5.5 2-6.2 6.2-.7-4.2-2-5.5-6.2-6.2 4.2-.7 5.5-2 6.2-6.2Z" />
    </>
  ),
  arrow: (
    <>
      <path d="M6 34c6-12 16-19 33-21" />
      <path d="M31 8c3.2 1.7 5.6 3.2 8 5-2.2 2.4-4 4.8-5.8 8.2" />
    </>
  ),
  smiley: (
    <>
      <circle cx="24" cy="24" r="17" />
      <path d="M17 21.5v-3M31 21.5v-3" />
      <path d="M16 29c2.6 4 5.4 6 8 6s5.4-2 8-6" />
    </>
  ),
  bulb: (
    <>
      <path d="M24 7c-6.6 0-11.5 5-11.5 11.2 0 4.3 2.2 6.6 4 9 1.2 1.6 1.7 2.6 1.9 4.3h11.2c.2-1.7.7-2.7 1.9-4.3 1.8-2.4 4-4.7 4-9C35.5 12 30.6 7 24 7Z" />
      <path d="M18.8 36.5h10.4M20.5 41h7" />
      <path d="M24 2.5v3M6 18h3M39 18h3M11 7l2 2M37 7l-2 2" />
    </>
  ),
  pencil: (
    <>
      <path d="M9 39l2.5-8L32 10.5c1.4-1.4 3.6-1.4 5 0l.6.6c1.4 1.4 1.4 3.6 0 5L17 36.5 9 39Z" />
      <path d="M29.5 13.5l5.5 5.5M11.5 31l5.5 5.5" />
    </>
  ),
  book: (
    <>
      <path d="M8 10c5-1.5 10-1.5 16 1.5V40c-6-3-11-3-16-1.5V10Z" />
      <path d="M40 10c-5-1.5-11-1.5-16 1.5V40c5-3 11-3 16-1.5V10Z" />
    </>
  ),
  crown: (
    <>
      <path d="M8 34 6 14l10 7 8-12 8 12 10-7-2 20H8Z" />
      <path d="M8 38h32" />
    </>
  ),
  check: <path d="M8 25.5 19 36 41 11" />,
  bubble: (
    <>
      <path d="M9 12h30a4 4 0 0 1 4 4v14a4 4 0 0 1-4 4H21l-9 8v-8H9a4 4 0 0 1-4-4V16a4 4 0 0 1 4-4Z" />
      <path d="M15 21h18M15 27h11" />
    </>
  ),
  squiggle: <path d="M4 28c5-9 9 9 14 0s9 9 14 0 9 5 12 1" />,
};

const FILLED: DoodleName[] = [];

export interface DoodleProps {
  name: DoodleName;
  className?: string;
  /** Tailwind text color class controls the stroke via currentColor. */
  size?: number;
  style?: CSSProperties;
  strokeWidth?: number;
}

/**
 * Simple hand-drawn style SVG doodle. Purely decorative.
 */
export function Doodle({ name, className, size = 40, style, strokeWidth = 2.4 }: DoodleProps) {
  return (
    <svg
      viewBox="0 0 48 48"
      width={size}
      height={size}
      aria-hidden
      focusable="false"
      className={cn("pointer-events-none select-none", className)}
      style={style}
      fill={FILLED.includes(name) ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {PATHS[name]}
    </svg>
  );
}

/**
 * Absolutely positioned decorative doodle, meant for card corners and
 * empty space. Never interactive.
 */
export function FloatingDoodle({
  name,
  className,
  size = 40,
  delay = 0,
  motion = "float",
  strokeWidth,
}: DoodleProps & { delay?: number; motion?: "float" | "sway" | "twinkle" | "none" }) {
  const anim =
    motion === "float"
      ? "animate-float-slow"
      : motion === "sway"
        ? "animate-sway"
        : motion === "twinkle"
          ? "animate-twinkle"
          : "";
  return (
    <span
      aria-hidden
      className={cn("pointer-events-none absolute", anim, className)}
      style={{ animationDelay: `${delay}s` }}
    >
      <Doodle name={name} size={size} {...(strokeWidth ? { strokeWidth } : {})} />
    </span>
  );
}
