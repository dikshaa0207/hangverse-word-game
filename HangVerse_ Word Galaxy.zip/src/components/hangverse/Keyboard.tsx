import { cn } from "@/lib/utils";

const ROWS = ["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"];

export function Keyboard({
  guessed,
  wrong,
  disabled,
  onGuess,
}: {
  guessed: Set<string>;
  wrong: Set<string>;
  disabled: boolean;
  onGuess: (letter: string) => void;
}) {
  return (
    <div className="flex flex-col items-center gap-1.5 sm:gap-2">
      {ROWS.map((row) => (
        <div key={row} className="flex w-full justify-center gap-1 sm:gap-1.5">
          {row.split("").map((letter) => {
            const used = guessed.has(letter);
            const isWrong = wrong.has(letter);
            return (
              <button
                key={letter}
                type="button"
                onClick={() => onGuess(letter)}
                disabled={disabled || used}
                aria-label={`Guess letter ${letter}`}
                aria-pressed={used}
                className={cn(
                  "h-10 min-w-0 flex-1 rounded-xl text-sm font-bold transition-all sm:h-12 sm:flex-none sm:w-11 sm:text-base",
                  "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                  !used &&
                    "bg-card text-card-foreground shadow-sm hover:-translate-y-0.5 hover:bg-secondary active:translate-y-0.5",
                  used && !isWrong && "bg-success text-success-foreground animate-pop-in",
                  isWrong && "bg-destructive/80 text-destructive-foreground opacity-70",
                  disabled && !used && "opacity-60",
                )}
              >
                {letter}
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
}
