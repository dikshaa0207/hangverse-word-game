import { useEffect, useState } from "react";

const COLORS = [
  "var(--color-primary)",
  "var(--color-mint)",
  "var(--color-lilac)",
  "var(--color-peach)",
  "var(--color-warning)",
];

export function Confetti({ active }: { active: boolean }) {
  const [pieces, setPieces] = useState<
    { id: number; left: number; delay: number; x: number; color: string; size: number }[]
  >([]);

  useEffect(() => {
    if (!active) {
      setPieces([]);
      return;
    }
    setPieces(
      Array.from({ length: 40 }, (_, id) => ({
        id,
        left: Math.random() * 100,
        delay: Math.random() * 0.8,
        x: (Math.random() - 0.5) * 160,
        color: COLORS[id % COLORS.length]!,
        size: 6 + Math.random() * 8,
      })),
    );
    const t = setTimeout(() => setPieces([]), 3600);
    return () => clearTimeout(t);
  }, [active]);

  if (!pieces.length) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden" aria-hidden>
      {pieces.map((p) => (
        <span
          key={p.id}
          className="absolute top-0 animate-confetti rounded-[2px]"
          style={{
            left: `${p.left}%`,
            width: p.size,
            height: p.size * 1.6,
            background: p.color,
            animationDelay: `${p.delay}s`,
            ["--confetti-x" as string]: `${p.x}px`,
          }}
        />
      ))}
    </div>
  );
}
