import { useEffect, useState } from "react";
import { Doodle } from "@/components/hangverse/Doodle";
import { cn } from "@/lib/utils";

export const QUOTES = [
  "Keep going, one guess at a time.",
  "Every mistake is a step closer to getting it right.",
  "Believe in your next guess.",
  "Small progress is still progress.",
  "Your next attempt could be your best one.",
  "Don't give up before the final guess.",
  "Learn something new with every word.",
  "Progress looks good on you.",
  "Keep guessing. Keep learning. Keep growing.",
] as const;

export function randomQuote() {
  return QUOTES[Math.floor(Math.random() * QUOTES.length)]!;
}

/**
 * Small scrapbook-style card that rotates a short motivational line.
 */
export function QuoteCard({
  className,
  intervalMs = 7000,
  heading = "A little reminder ✿",
}: {
  className?: string;
  intervalMs?: number;
  heading?: string;
}) {
  const [index, setIndex] = useState(0);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const id = setInterval(() => {
      setVisible(false);
      setTimeout(() => {
        setIndex((i) => (i + 1) % QUOTES.length);
        setVisible(true);
      }, 320);
    }, intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);

  return (
    <aside
      className={cn(
        "paper-cream tilt-2 relative rounded-3xl px-6 py-5 text-center",
        className,
      )}
    >
      <Doodle
        name="sparkle"
        size={28}
        className="absolute -left-2 -top-3 rotate-[-12deg] text-lavender animate-twinkle"
      />
      <Doodle
        name="flower"
        size={26}
        className="absolute -bottom-3 -right-2 text-blush"
        strokeWidth={2}
      />
      <p className="hand text-2xl font-bold text-primary">{heading}</p>
      <p
        className={cn(
          "hand mt-1 text-2xl leading-snug text-ink transition-opacity duration-300 sm:text-3xl",
          visible ? "opacity-100" : "opacity-0",
        )}
      >
        “{QUOTES[index]}”
      </p>
    </aside>
  );
}
