import { Doodle } from "@/components/hangverse/Doodle";

/**
 * Tiny one-shot sparkle burst shown when a guess is correct.
 * Remount with a changing `key` to replay.
 */
export function SparkleBurst({ show }: { show: boolean }) {
  if (!show) return null;
  const bits = [
    { left: "18%", top: "12%", size: 22, delay: 0 },
    { left: "48%", top: "4%", size: 28, delay: 0.08 },
    { left: "78%", top: "16%", size: 20, delay: 0.16 },
    { left: "32%", top: "70%", size: 18, delay: 0.12 },
    { left: "68%", top: "62%", size: 24, delay: 0.2 },
  ];
  return (
    <div className="pointer-events-none absolute inset-0 z-10 overflow-hidden" aria-hidden>
      {bits.map((b, i) => (
        <span
          key={i}
          className="absolute animate-sparkle-pop text-warning"
          style={{ left: b.left, top: b.top, animationDelay: `${b.delay}s` }}
        >
          <Doodle name="sparkle" size={b.size} strokeWidth={2} />
        </span>
      ))}
    </div>
  );
}
