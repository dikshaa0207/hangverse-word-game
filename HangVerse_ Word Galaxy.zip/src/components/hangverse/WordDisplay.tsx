import { cn } from "@/lib/utils";

export function WordDisplay({
  word,
  guessed,
  reveal,
  shake,
}: {
  word: string;
  guessed: Set<string>;
  reveal: boolean;
  shake: boolean;
}) {
  return (
    <div
      className={cn("flex flex-wrap justify-center gap-1.5 sm:gap-2.5", shake && "animate-shake")}
      aria-label="Hidden word"
    >
      {word.split("").map((ch, i) => {
        if (ch === " ") return <span key={i} className="w-4 sm:w-6" />;
        const shown = guessed.has(ch) || reveal;
        return (
          <span
            key={i}
            className={cn(
              "grid h-12 w-8 place-items-center rounded-lg border-b-4 font-display text-xl font-extrabold transition-colors sm:h-14 sm:w-10 sm:text-2xl",
              shown
                ? "border-primary bg-card text-foreground animate-pop-in"
                : "border-primary/40 bg-card/40 text-transparent",
            )}
          >
            {shown ? ch : "•"}
          </span>
        );
      })}
    </div>
  );
}
