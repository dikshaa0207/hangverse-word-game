export function HangmanDrawing({ wrong, max }: { wrong: number; max: number }) {
  const parts = Math.min(6, Math.round((wrong / max) * 6 + (wrong > 0 ? 0.4 : 0)));
  const show = (n: number) => parts >= n;

  return (
    <svg
      viewBox="0 0 200 220"
      className="h-56 w-full max-w-[240px] sm:h-64"
      role="img"
      aria-label={`Hangman drawing: ${wrong} of ${max} wrong guesses`}
    >
      <g
        stroke="currentColor"
        className="text-primary/70"
        strokeWidth="7"
        strokeLinecap="round"
        fill="none"
      >
        <line x1="20" y1="205" x2="120" y2="205" />
        <line x1="60" y1="205" x2="60" y2="20" />
        <line x1="60" y1="20" x2="140" y2="20" />
        <line x1="140" y1="20" x2="140" y2="45" />
      </g>
      <g
        stroke="currentColor"
        className="text-destructive"
        strokeWidth="6"
        strokeLinecap="round"
        fill="none"
      >
        {show(1) && <circle cx="140" cy="65" r="20" className="animate-pop-in" />}
        {show(2) && <line x1="140" y1="85" x2="140" y2="140" className="animate-pop-in" />}
        {show(3) && <line x1="140" y1="100" x2="115" y2="122" className="animate-pop-in" />}
        {show(4) && <line x1="140" y1="100" x2="165" y2="122" className="animate-pop-in" />}
        {show(5) && <line x1="140" y1="140" x2="118" y2="175" className="animate-pop-in" />}
        {show(6) && <line x1="140" y1="140" x2="162" y2="175" className="animate-pop-in" />}
      </g>
      {show(6) && (
        <g className="animate-pop-in" stroke="currentColor" strokeWidth="3" strokeLinecap="round">
          <line x1="133" y1="60" x2="139" y2="66" className="text-foreground" />
          <line x1="139" y1="60" x2="133" y2="66" className="text-foreground" />
          <line x1="141" y1="60" x2="147" y2="66" className="text-foreground" />
          <line x1="147" y1="60" x2="141" y2="66" className="text-foreground" />
        </g>
      )}
    </svg>
  );
}
