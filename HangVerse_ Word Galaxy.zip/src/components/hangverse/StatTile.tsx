import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function StatTile({
  label,
  value,
  icon,
  tone = "primary",
}: {
  label: string;
  value: ReactNode;
  icon?: ReactNode;
  tone?: "primary" | "success" | "warning" | "accent" | "destructive";
}) {
  const tones = {
    primary: "bg-primary/12 text-primary",
    success: "bg-success/20 text-success-foreground",
    warning: "bg-warning/25 text-warning-foreground",
    accent: "bg-accent/40 text-accent-foreground",
    destructive: "bg-destructive/15 text-destructive",
  } as const;

  return (
    <div className="glass rounded-2xl p-4 animate-rise">
      <div className="flex items-center gap-3">
        {icon ? (
          <span className={cn("grid size-10 shrink-0 place-items-center rounded-xl", tones[tone])}>
            {icon}
          </span>
        ) : null}
        <div className="min-w-0">
          <p className="truncate text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            {label}
          </p>
          <p className="font-display text-2xl font-extrabold">{value}</p>
        </div>
      </div>
    </div>
  );
}
