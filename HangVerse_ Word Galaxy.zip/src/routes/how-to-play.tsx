import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/hangverse/PageShell";
import { DIFFICULTY_CONFIG } from "@/lib/hangverse/words";
import { POINTS } from "@/lib/hangverse/scoring";

export const Route = createFileRoute("/how-to-play")({
  head: () => ({
    meta: [
      { title: "How to Play — HangVerse Rules & Scoring" },
      {
        name: "description",
        content:
          "Learn the HangVerse rules: lives per difficulty, how hints work, how scoring and coins are calculated, and how streaks are tracked.",
      },
      { property: "og:title", content: "How to Play — HangVerse Rules & Scoring" },
      {
        property: "og:description",
        content: "Rules, hints, scoring and coins explained for the HangVerse hangman game.",
      },
    ],
  }),
  component: HowToPlay,
});

const STEPS = [
  {
    emoji: "🎯",
    title: "Pick your challenge",
    body: "Choose one of ten categories or hit Random, then set the difficulty. Harder rounds have longer words, fewer lives and fewer hints — but score much more.",
  },
  {
    emoji: "🔤",
    title: "Guess letters",
    body: "Tap the on-screen keyboard or type on your physical keyboard. Each letter can only be guessed once, and only A–Z inputs count.",
  },
  {
    emoji: "❤️",
    title: "Watch your lives",
    body: "Every wrong letter draws one more piece of the hangman. When the drawing is complete, the round ends.",
  },
  {
    emoji: "💡",
    title: "Use hints wisely",
    body: "Your first hint describes the word. Later hints reveal a letter — never the last one — so the win is always yours. Hints cost points.",
  },
  {
    emoji: "📖",
    title: "Learn the word",
    body: "Win or lose, every round finishes with the word's meaning and an interesting fact, which is then saved to your Learning Library.",
  },
  {
    emoji: "🏅",
    title: "Build your profile",
    body: "Coins, streaks, best score, history and achievements are stored in your browser, so your progress is still there tomorrow.",
  },
];

function HowToPlay() {
  return (
    <PageShell title="How to Play" subtitle="Everything you need in under a minute.">
      <div className="grid gap-4 sm:grid-cols-2">
        {STEPS.map((s) => (
          <div key={s.title} className="glass rounded-2xl p-5 animate-rise">
            <div className="text-3xl">{s.emoji}</div>
            <h2 className="mt-2 font-display text-lg font-bold">{s.title}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{s.body}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <div className="glass rounded-2xl p-5">
          <h2 className="font-display text-lg font-bold">Difficulty at a glance</h2>
          <table className="mt-3 w-full text-sm">
            <thead>
              <tr className="text-left text-muted-foreground">
                <th className="py-1 font-semibold">Level</th>
                <th className="py-1 font-semibold">Lives</th>
                <th className="py-1 font-semibold">Hints</th>
                <th className="py-1 font-semibold">Points ×</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(DIFFICULTY_CONFIG).map(([key, cfg]) => (
                <tr key={key} className="border-t border-border/60">
                  <td className="py-2 font-bold">{cfg.label}</td>
                  <td className="py-2">{cfg.attempts}</td>
                  <td className="py-2">{cfg.hints}</td>
                  <td className="py-2">{cfg.multiplier}×</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="glass rounded-2xl p-5">
          <h2 className="font-display text-lg font-bold">Scoring</h2>
          <ul className="mt-3 space-y-2 text-sm">
            <li className="rounded-xl bg-success/20 px-3 py-2">
              Correct letter: <strong>+{POINTS.correctLetter}</strong> per matching position, scaled
              by difficulty.
            </li>
            <li className="rounded-xl bg-destructive/12 px-3 py-2">
              Wrong guess: <strong>{POINTS.wrongGuess}</strong> points.
            </li>
            <li className="rounded-xl bg-warning/20 px-3 py-2">
              Hint used: <strong>{POINTS.hint}</strong> points.
            </li>
            <li className="rounded-xl bg-primary/12 px-3 py-2">
              Win bonus: <strong>{POINTS.winBase}</strong> plus {POINTS.perAttemptLeft} per unused
              life, scaled by difficulty.
            </li>
            <li className="rounded-xl bg-accent/40 px-3 py-2">
              Coins: earned every completed round — more for harder wins with lives to spare.
            </li>
          </ul>
        </div>
      </div>

      <Link
        to="/play"
        className="press mt-6 inline-block rounded-2xl bg-primary px-6 py-3 font-display font-extrabold text-primary-foreground shadow-md"
      >
        Start Game
      </Link>
    </PageShell>
  );
}
