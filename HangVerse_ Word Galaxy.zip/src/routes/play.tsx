import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Heart, Lightbulb, RotateCcw, Sparkles } from "lucide-react";
import { PageShell } from "@/components/hangverse/PageShell";
import { HangmanDrawing } from "@/components/hangverse/HangmanDrawing";
import { Keyboard } from "@/components/hangverse/Keyboard";
import { WordDisplay } from "@/components/hangverse/WordDisplay";
import { Confetti } from "@/components/hangverse/Confetti";
import { Doodle, FloatingDoodle } from "@/components/hangverse/Doodle";
import { SparkleBurst } from "@/components/hangverse/SparkleBurst";
import { randomQuote } from "@/components/hangverse/QuoteCard";
import { useHangVerse } from "@/lib/hangverse/store";
import {
  CATEGORIES,
  CATEGORY_MAP,
  DIFFICULTY_CONFIG,
  difficultyOf,
  pickWord,
  wordKey,
  type CategoryId,
  type Difficulty,
  type WordEntry,
} from "@/lib/hangverse/words";
import {
  LOSS_MESSAGES,
  POINTS,
  WIN_MESSAGES,
  coinsFor,
  pickMessage,
  scoreCorrectLetter,
  winBonus,
} from "@/lib/hangverse/scoring";
import { achievementById } from "@/lib/hangverse/achievements";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/play")({
  head: () => ({
    meta: [
      { title: "Play HangVerse — Unlimited Hangman Rounds" },
      {
        name: "description",
        content:
          "Pick a category and difficulty, then guess the hidden word letter by letter with hints, lives and live scoring.",
      },
      { property: "og:title", content: "Play HangVerse — Unlimited Hangman Rounds" },
      {
        property: "og:description",
        content: "Choose a category, set your difficulty and start guessing in HangVerse.",
      },
    ],
  }),
  component: PlayPage,
});

type Phase = "setup" | "playing" | "won" | "lost";

interface Round {
  entry: WordEntry;
  difficulty: Difficulty;
  maxWrong: number;
  maxHints: number;
}

function PlayPage() {
  const { state, hydrated, update, recordRound } = useHangVerse();

  const [phase, setPhase] = useState<Phase>("setup");
  const [category, setCategory] = useState<CategoryId | "random">("random");
  const [difficulty, setDifficulty] = useState<Difficulty>("easy");
  const [round, setRound] = useState<Round | null>(null);
  const [guessed, setGuessed] = useState<Set<string>>(new Set());
  const [wrong, setWrong] = useState<Set<string>>(new Set());
  const [score, setScore] = useState(0);
  const [hintsUsed, setHintsUsed] = useState(0);
  const [hintTexts, setHintTexts] = useState<string[]>([]);
  const [shake, setShake] = useState(false);
  const [sparkle, setSparkle] = useState(0);
  const [flash, setFlash] = useState<string | null>(null);
  const [summary, setSummary] = useState<{
    message: string;
    coins: number;
    finalScore: number;
    unlocked: string[];
    quote: string;
  } | null>(null);

  useEffect(() => {
    if (hydrated) {
      setCategory(state.lastCategory);
      setDifficulty(state.lastDifficulty);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated]);

  const letters = useMemo(
    () => (round ? Array.from(new Set(round.entry.word.replace(/[^A-Z]/g, "").split(""))) : []),
    [round],
  );
  const solved = round ? letters.every((l) => guessed.has(l)) : false;
  const attemptsLeft = round ? round.maxWrong - wrong.size : 0;

  const showFlash = useCallback((text: string) => {
    setFlash(text);
    setTimeout(() => setFlash(null), 1400);
  }, []);

  const startRound = useCallback(
    (cat: CategoryId | "random", diff: Difficulty) => {
      const { entry, poolReset } = pickWord(cat, diff, state.usedWordKeys);
      const cfg = DIFFICULTY_CONFIG[diff];
      if (poolReset) {
        update({ usedWordKeys: [] });
        showFlash("Word pool refreshed — every word has been played!");
      } else {
        update((s) => ({ usedWordKeys: [...s.usedWordKeys, wordKey(entry)] }));
      }
      update({ lastCategory: cat, lastDifficulty: diff });
      setRound({
        entry,
        difficulty: diff,
        maxWrong: cfg.attempts,
        maxHints: cfg.hints,
      });
      setGuessed(new Set());
      setWrong(new Set());
      setScore(0);
      setHintsUsed(0);
      setHintTexts([]);
      setSummary(null);
      setPhase("playing");
    },
    [state.usedWordKeys, update, showFlash],
  );

  const finishRound = useCallback(
    (result: "won" | "lost", finalScore: number, r: Round, wrongCount: number, hints: number) => {
      const attempts = Math.max(0, r.maxWrong - wrongCount);
      const coins = coinsFor(result, r.difficulty, attempts);
      const { unlocked } = recordRound({
        word: r.entry.word,
        wordKey: wordKey(r.entry),
        category: r.entry.category,
        difficulty: r.difficulty,
        result,
        score: finalScore,
        hintsUsed: hints,
        wrongGuesses: wrongCount,
        coinsEarned: coins,
      });
      setSummary({
        message: pickMessage(result === "won" ? WIN_MESSAGES : LOSS_MESSAGES),
        coins,
        finalScore,
        unlocked,
        quote: randomQuote(),
      });
      setPhase(result === "won" ? "won" : "lost");
    },
    [recordRound],
  );

  const guess = useCallback(
    (raw: string) => {
      const letter = raw.toUpperCase();
      if (phase !== "playing" || !round) return;
      if (!/^[A-Z]$/.test(letter)) return;
      if (guessed.has(letter) || wrong.has(letter)) return;

      const occurrences = round.entry.word.split("").filter((c) => c === letter).length;

      if (occurrences > 0) {
        const nextGuessed = new Set(guessed).add(letter);
        setGuessed(nextGuessed);
        setSparkle((n) => n + 1);
        const gain = scoreCorrectLetter(round.difficulty, occurrences);
        const nextScore = score + gain;
        setScore(nextScore);
        const allFound = letters.every((l) => nextGuessed.has(l));
        if (allFound) {
          const bonus = winBonus(round.difficulty, round.maxWrong - wrong.size);
          finishRound("won", Math.max(0, nextScore + bonus), round, wrong.size, hintsUsed);
        }
      } else {
        const nextWrong = new Set(wrong).add(letter);
        setWrong(nextWrong);
        const nextScore = Math.max(0, score + POINTS.wrongGuess);
        setScore(nextScore);
        setShake(true);
        setTimeout(() => setShake(false), 450);
        if (nextWrong.size >= round.maxWrong) {
          finishRound("lost", nextScore, round, nextWrong.size, hintsUsed);
        }
      }
    },
    [phase, round, guessed, wrong, score, letters, hintsUsed, finishRound],
  );

  useEffect(() => {
    if (phase !== "playing") return;
    const onKey = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (/^[a-zA-Z]$/.test(e.key)) guess(e.key);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [guess, phase]);

  const useHint = useCallback(() => {
    if (!round || phase !== "playing") return;
    if (hintsUsed >= round.maxHints) {
      showFlash("No hints left for this round.");
      return;
    }
    const remaining = letters.filter((l) => !guessed.has(l));

    if (hintsUsed === 0) {
      setHintTexts((t) => [...t, round.entry.hint]);
      showFlash("💡 Hint revealed!");
    } else if (remaining.length > 1) {
      const reveal = remaining[Math.floor(Math.random() * remaining.length)]!;
      setGuessed((g) => new Set(g).add(reveal));
      setHintTexts((t) => [...t, `The word contains the letter "${reveal}".`]);
      showFlash(`💡 Letter "${reveal}" revealed!`);
    } else {
      const vowels = letters.filter((l) => "AEIOU".includes(l)).length;
      setHintTexts((t) => [
        ...t,
        `This word has ${letters.length} unique letters and ${vowels} distinct vowels.`,
      ]);
      showFlash("💡 Extra clue revealed!");
    }

    setHintsUsed((h) => h + 1);
    setScore((s) => Math.max(0, s + POINTS.hint));
  }, [round, phase, hintsUsed, letters, guessed, showFlash]);

  const backToSetup = () => {
    setPhase("setup");
    setRound(null);
    setSummary(null);
  };

  if (phase === "setup" || !round) {
    return (
      <PageShell title="New Round" subtitle="Pick a category and difficulty to begin.">
        <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
          <div className="paper relative rounded-3xl p-5 sm:p-6">
            <FloatingDoodle
              name="star"
              size={28}
              className="right-4 top-3 text-warning/70"
              motion="twinkle"
            />
            <h2 className="font-display text-lg font-bold">Category</h2>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
              <CategoryButton
                active={category === "random"}
                onClick={() => setCategory("random")}
                emoji="🎲"
                name="Random"
              />
              {CATEGORIES.map((c) => (
                <CategoryButton
                  key={c.id}
                  active={category === c.id}
                  onClick={() => setCategory(c.id)}
                  emoji={c.emoji}
                  name={c.name}
                />
              ))}
            </div>

            <h2 className="mt-6 font-display text-lg font-bold">Difficulty</h2>
            <div className="mt-3 grid gap-2 sm:grid-cols-3">
              {(Object.keys(DIFFICULTY_CONFIG) as Difficulty[]).map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setDifficulty(d)}
                  aria-pressed={difficulty === d}
                  className={cn(
                    "press rounded-2xl px-4 py-3 text-left ring-1 transition-colors",
                    difficulty === d
                      ? "bg-primary text-primary-foreground ring-primary"
                      : "bg-card ring-border hover:bg-secondary",
                  )}
                >
                  <p className="font-display font-bold">{DIFFICULTY_CONFIG[d].label}</p>
                  <p className="text-xs opacity-80">{DIFFICULTY_CONFIG[d].blurb}</p>
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => startRound(category, difficulty)}
              className="press mt-6 w-full rounded-2xl bg-primary px-6 py-4 font-display text-lg font-extrabold text-primary-foreground shadow-md"
            >
              Start Round
            </button>
          </div>

          <aside className="paper-cream tilt-2 relative rounded-3xl p-5 sm:p-6">
            <Doodle
              name="crown"
              size={30}
              strokeWidth={2.2}
              className="absolute right-4 top-4 text-warning-foreground/60"
            />
            <h2 className="font-display text-lg font-bold">Your progress</h2>
            <ul className="mt-3 space-y-2 text-sm">
              <Row label="Coins" value={hydrated ? state.coins : 0} />
              <Row label="Best score" value={hydrated ? state.bestScore : 0} />
              <Row label="Current streak" value={hydrated ? state.currentStreak : 0} />
              <Row label="Words discovered" value={hydrated ? state.discoveredKeys.length : 0} />
            </ul>
            <p className="mt-4 rounded-2xl bg-secondary/70 p-3 text-xs text-muted-foreground">
              Scoring: +{POINTS.correctLetter} per correct letter (scaled by difficulty),{" "}
              {POINTS.wrongGuess} per wrong guess, {POINTS.hint} per hint, plus a win bonus for
              every life you keep.
            </p>
            <Link
              to="/how-to-play"
              className="press mt-4 block rounded-2xl bg-card px-4 py-3 text-center text-sm font-bold ring-1 ring-border"
            >
              How to Play
            </Link>
          </aside>
        </div>
        {flash ? <FlashToast text={flash} /> : null}
      </PageShell>
    );
  }

  const finished = phase === "won" || phase === "lost";
  const cat = CATEGORY_MAP[round.entry.category];

  return (
    <PageShell>
      <Confetti active={phase === "won"} />
      <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
        <section className="paper relative rounded-3xl p-5">
          <FloatingDoodle
            name="cloud"
            size={44}
            className="-left-3 -top-4 text-primary/30"
            motion="float"
          />
          <div className="flex items-center justify-between gap-2">
            <span className="rounded-full bg-secondary px-3 py-1 text-sm font-bold text-secondary-foreground">
              {cat.emoji} {cat.name}
            </span>
            <span className="rounded-full bg-accent/50 px-3 py-1 text-sm font-bold text-accent-foreground">
              {DIFFICULTY_CONFIG[round.difficulty].label}
            </span>
          </div>
          <div className="mt-2 flex justify-center">
            <HangmanDrawing wrong={wrong.size} max={round.maxWrong} />
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <Mini icon={<Heart className="size-4" />} label="Lives" value={attemptsLeft} />
            <Mini icon={<Sparkles className="size-4" />} label="Score" value={score} />
            <Mini
              icon={<Lightbulb className="size-4" />}
              label="Hints"
              value={`${round.maxHints - hintsUsed}`}
            />
          </div>
        </section>

        <section
          className={cn(
            "paper relative rounded-3xl p-5 sm:p-6",
            shake && "animate-shake",
          )}
        >
          <SparkleBurst key={sparkle} show={sparkle > 0 && !finished} />
          <FloatingDoodle
            name="pencil"
            size={34}
            className="-right-2 -top-3 rotate-12 text-muted-foreground/50"
            motion="sway"
            delay={0.6}
          />
          <WordDisplay
            word={round.entry.word}
            guessed={guessed}
            reveal={finished}
            shake={false}
          />

          <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-sm">
            <span className="rounded-full bg-destructive/12 px-3 py-1 font-semibold text-destructive">
              Wrong: {wrong.size ? Array.from(wrong).join(" ") : "none yet"}
            </span>
            <span className="rounded-full bg-success/20 px-3 py-1 font-semibold text-success-foreground">
              Found: {Array.from(guessed).filter((g) => letters.includes(g)).join(" ") || "none yet"}
            </span>
          </div>

          {hintTexts.length ? (
            <ul className="mt-4 space-y-2">
              {hintTexts.map((h, i) => (
                <li
                  key={i}
                  className="animate-pop-in rounded-2xl bg-warning/20 px-4 py-2 text-sm font-medium text-warning-foreground"
                >
                  💡 {h}
                </li>
              ))}
            </ul>
          ) : null}

          {!finished ? (
            <>
              <div className="mt-5">
                <Keyboard guessed={guessed} wrong={wrong} disabled={finished} onGuess={guess} />
              </div>
              <div className="mt-5 flex flex-wrap justify-center gap-2">
                <button
                  type="button"
                  onClick={useHint}
                  disabled={hintsUsed >= round.maxHints}
                  className="press inline-flex items-center gap-2 rounded-2xl bg-warning px-5 py-3 font-bold text-warning-foreground shadow-sm disabled:opacity-50"
                >
                  <Lightbulb className="size-4" aria-hidden />
                  Hint ({round.maxHints - hintsUsed} left)
                </button>
                <button
                  type="button"
                  onClick={backToSetup}
                  className="press inline-flex items-center gap-2 rounded-2xl bg-card px-5 py-3 font-bold ring-1 ring-border"
                >
                  <RotateCcw className="size-4" aria-hidden />
                  Change round
                </button>
              </div>
              <p className="mt-3 text-center text-xs text-muted-foreground">
                Tip: you can type letters on your physical keyboard too.
              </p>
            </>
          ) : (
            <ResultPanel
              won={phase === "won"}
              entry={round.entry}
              summary={summary}
              streak={state.currentStreak}
              onPlayAgain={() => startRound(category, difficulty)}
            />
          )}
        </section>
      </div>
      {flash ? <FlashToast text={flash} /> : null}
    </PageShell>
  );
}

function ResultPanel({
  won,
  entry,
  summary,
  streak,
  onPlayAgain,
}: {
  won: boolean;
  entry: WordEntry;
  summary: {
    message: string;
    coins: number;
    finalScore: number;
    unlocked: string[];
    quote: string;
  } | null;
  streak: number;
  onPlayAgain: () => void;
}) {
  return (
    <div className="paper-cream relative mt-6 animate-rise overflow-hidden rounded-3xl p-5 sm:p-6">
      {won ? (
        <>
          <FloatingDoodle
            name="star"
            size={30}
            className="left-4 top-3 text-warning"
            motion="twinkle"
          />
          <FloatingDoodle
            name="sparkle"
            size={34}
            className="right-5 top-6 text-lavender"
            motion="sway"
            delay={0.5}
          />
          <FloatingDoodle
            name="heart"
            size={26}
            className="bottom-6 right-8 text-blush"
            motion="float"
            delay={1}
          />
        </>
      ) : (
        <FloatingDoodle
          name="cloud"
          size={44}
          className="right-4 top-4 text-primary/30"
          motion="float"
        />
      )}

      <h2
        className={cn(
          "relative font-display text-3xl font-extrabold",
          won ? "text-success-foreground" : "text-primary",
        )}
      >
        {won ? "You did it! ✦" : "Almost there ✿"}
      </h2>
      <p className="hand mt-1 text-2xl text-muted-foreground">
        {summary?.message}
      </p>

      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        <SmallStat label="Final score" value={summary?.finalScore ?? 0} />
        <SmallStat label="Coins earned" value={`+${summary?.coins ?? 0}`} />
        <SmallStat label="Current streak" value={streak} />
      </div>

      <p className="hand mt-4 flex items-center gap-2 text-2xl text-primary">
        <Doodle name="bulb" size={24} strokeWidth={2.4} />
        {summary?.quote}
      </p>


      <div className="mt-4 rounded-2xl bg-secondary/70 p-4">
        <p className="font-display text-lg font-bold">
          {entry.word}{" "}
          <span className="text-sm font-semibold text-muted-foreground">
            · {CATEGORY_MAP[entry.category].name} · {DIFFICULTY_CONFIG[difficultyOf(entry.word)].label}
          </span>
        </p>
        <p className="mt-2 text-sm">
          <strong>Meaning:</strong> {entry.meaning}
        </p>
        <p className="mt-1 text-sm">
          <strong>Did you know?</strong> {entry.fact}
        </p>
      </div>

      {summary?.unlocked.length ? (
        <div className="mt-4 space-y-2">
          {summary.unlocked.map((id) => {
            const a = achievementById(id);
            if (!a) return null;
            return (
              <div
                key={id}
                className="animate-pop-in rounded-2xl bg-accent/50 px-4 py-3 text-sm font-bold text-accent-foreground"
              >
                🏅 Achievement unlocked — {a.emoji} {a.name}
              </div>
            );
          })}
        </div>
      ) : null}

      <div className="mt-5 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={onPlayAgain}
          className="press rounded-2xl bg-primary px-6 py-3 font-display font-extrabold text-primary-foreground shadow-md"
        >
          Play Again
        </button>
        <Link
          to="/"
          className="press rounded-2xl bg-card px-6 py-3 font-bold ring-1 ring-border"
        >
          Back to Home
        </Link>
        <Link
          to="/library"
          className="press rounded-2xl bg-secondary px-6 py-3 font-bold text-secondary-foreground"
        >
          Learning Library
        </Link>
      </div>
    </div>
  );
}

function CategoryButton({
  active,
  onClick,
  emoji,
  name,
}: {
  active: boolean;
  onClick: () => void;
  emoji: string;
  name: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "press rounded-2xl px-3 py-3 text-sm font-bold ring-1 transition-colors",
        active
          ? "bg-primary text-primary-foreground ring-primary"
          : "bg-card ring-border hover:bg-secondary",
      )}
    >
      <span className="mr-1">{emoji}</span>
      {name}
    </button>
  );
}

function Row({ label, value }: { label: string; value: number | string }) {
  return (
    <li className="flex items-center justify-between rounded-xl bg-card/70 px-3 py-2">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-display font-bold">{value}</span>
    </li>
  );
}

function Mini({ icon, label, value }: { icon: React.ReactNode; label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-2xl bg-card/70 px-2 py-2">
      <span className="flex items-center justify-center gap-1 text-xs font-semibold text-muted-foreground">
        {icon}
        {label}
      </span>
      <p className="font-display text-xl font-extrabold">{value}</p>
    </div>
  );
}

function SmallStat({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-2xl bg-secondary/70 px-4 py-3 text-center">
      <p className="text-xs font-semibold uppercase text-muted-foreground">{label}</p>
      <p className="font-display text-xl font-extrabold">{value}</p>
    </div>
  );
}

function FlashToast({ text }: { text: string }) {
  return (
    <div
      role="status"
      className="pointer-events-none fixed bottom-6 left-1/2 z-40 -translate-x-1/2 animate-pop-in rounded-full bg-card px-5 py-3 text-sm font-bold shadow-lg ring-1 ring-border"
    >
      {text}
    </div>
  );
}

