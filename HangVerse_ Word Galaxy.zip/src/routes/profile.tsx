import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Coins, Flame, Gamepad2, Star, Trophy } from "lucide-react";
import { PageShell } from "@/components/hangverse/PageShell";
import { StatTile } from "@/components/hangverse/StatTile";
import { useHangVerse } from "@/lib/hangverse/store";
import { ACHIEVEMENTS } from "@/lib/hangverse/achievements";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Player Profile — HangVerse Dashboard" },
      {
        name: "description",
        content:
          "Your HangVerse dashboard: player name, total games, wins, current streak, best score, coins and unlocked achievements.",
      },
      { property: "og:title", content: "Player Profile — HangVerse Dashboard" },
      {
        property: "og:description",
        content: "See your HangVerse player card, coins, streak and badges in one place.",
      },
    ],
  }),
  component: Profile,
});

function Profile() {
  const { state, hydrated, update, resetProgress } = useHangVerse();
  const [name, setName] = useState(state.playerName);
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    if (hydrated) setName(state.playerName);
  }, [hydrated, state.playerName]);

  const saveName = () => {
    const clean = name.trim().slice(0, 24);
    update({ playerName: clean.length ? clean : "Player One" });
  };

  const unlocked = ACHIEVEMENTS.filter((a) => state.achievements[a.id]);

  return (
    <PageShell title="Player Profile" subtitle="Your HangVerse dashboard.">
      <section className="glass-strong rounded-3xl p-6">
        <div className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-4">
          <span className="grid size-16 shrink-0 place-items-center rounded-3xl bg-primary font-display text-2xl font-extrabold text-primary-foreground">
            {(hydrated ? state.playerName : "P").charAt(0).toUpperCase()}
          </span>
          <div className="min-w-0">
            <p className="text-xs font-semibold uppercase text-muted-foreground">Player</p>
            <h2 className="truncate font-display text-2xl font-extrabold">
              {hydrated ? state.playerName : "Player One"}
            </h2>
          </div>
        </div>

        <div className="mt-4 grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto]">
          <label className="min-w-0">
            <span className="sr-only">Player name</span>
            <input
              value={name}
              maxLength={24}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-2xl bg-card px-4 py-3 text-sm ring-1 ring-border focus:outline-none focus:ring-2 focus:ring-ring"
              placeholder="Enter your name"
            />
          </label>
          <button
            type="button"
            onClick={saveName}
            className="press rounded-2xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground"
          >
            Save name
          </button>
        </div>
      </section>

      <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <StatTile
          label="Total games"
          value={hydrated ? state.gamesPlayed : 0}
          icon={<Gamepad2 className="size-5" />}
        />
        <StatTile
          label="Wins"
          value={hydrated ? state.gamesWon : 0}
          tone="success"
          icon={<Trophy className="size-5" />}
        />
        <StatTile
          label="Current streak"
          value={hydrated ? state.currentStreak : 0}
          tone="destructive"
          icon={<Flame className="size-5" />}
        />
        <StatTile
          label="Best score"
          value={hydrated ? state.bestScore : 0}
          icon={<Star className="size-5" />}
        />
        <StatTile
          label="Coins"
          value={hydrated ? state.coins : 0}
          tone="warning"
          icon={<Coins className="size-5" />}
        />
        <StatTile
          label="Achievements"
          value={`${unlocked.length}/${ACHIEVEMENTS.length}`}
          tone="accent"
          icon={<Trophy className="size-5" />}
        />
      </div>

      <section className="mt-5 glass rounded-3xl p-5">
        <h2 className="font-display text-lg font-bold">Badge case</h2>
        {unlocked.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">
            No badges yet — win a round to earn your first one.
          </p>
        ) : (
          <div className="mt-3 flex flex-wrap gap-2">
            {unlocked.map((a) => (
              <span
                key={a.id}
                className="rounded-full bg-accent/50 px-3 py-1.5 text-sm font-bold text-accent-foreground"
              >
                {a.emoji} {a.name}
              </span>
            ))}
          </div>
        )}
        <Link
          to="/achievements"
          className="press mt-4 inline-block rounded-2xl bg-card px-5 py-2.5 text-sm font-bold ring-1 ring-border"
        >
          View all achievements
        </Link>
      </section>

      <section className="mt-5 rounded-3xl bg-destructive/8 p-5 ring-1 ring-destructive/30">
        <h2 className="font-display text-lg font-bold text-destructive">Reset progress</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          This clears stats, coins, achievements, history and your discovered words. It cannot be
          undone.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setConfirming((c) => !c)}
            className={cn(
              "press rounded-2xl px-5 py-2.5 text-sm font-bold ring-1",
              confirming ? "bg-card ring-border" : "bg-destructive/15 text-destructive ring-destructive/40",
            )}
          >
            {confirming ? "Cancel" : "Reset everything"}
          </button>
          {confirming ? (
            <button
              type="button"
              onClick={() => {
                resetProgress();
                setConfirming(false);
              }}
              className="press rounded-2xl bg-destructive px-5 py-2.5 text-sm font-bold text-destructive-foreground"
            >
              Yes, delete my progress
            </button>
          ) : null}
        </div>
      </section>
    </PageShell>
  );
}
