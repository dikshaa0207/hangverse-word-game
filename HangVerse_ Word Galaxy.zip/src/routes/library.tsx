import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState, type ReactNode } from "react";
import { PageShell } from "@/components/hangverse/PageShell";
import { useHangVerse } from "@/lib/hangverse/store";
import {
  CATEGORIES,
  CATEGORY_MAP,
  DIFFICULTY_CONFIG,
  WORDS,
  difficultyOf,
  wordKey,
  type CategoryId,
  type Difficulty,
} from "@/lib/hangverse/words";
import { cn } from "@/lib/utils";

type SortMode = "alpha" | "discovered" | "difficulty";
type DifficultyFilter = Difficulty | "all";

export const Route = createFileRoute("/library")({
  head: () => ({
    meta: [
      { title: "Learning Library — Word Meanings & Facts" },
      {
        name: "description",
        content:
          "Search and filter your discovered HangVerse words by category, difficulty and meaning. Browse facts for every word you've played.",
      },
      { property: "og:title", content: "Learning Library — Word Meanings & Facts" },
      {
        property: "og:description",
        content: "Your growing collection of discovered words, meanings and facts in HangVerse.",
      },
    ],
  }),
  component: Library,
});

function Library() {
  const { state, hydrated } = useHangVerse();
  const [category, setCategory] = useState<CategoryId | "all">("all");
  const [difficulty, setDifficulty] = useState<DifficultyFilter>("all");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortMode>("alpha");

  const discovered = useMemo(
    () => new Set(hydrated ? state.discoveredKeys : []),
    [state.discoveredKeys, hydrated],
  );

  const discoveredOrder = useMemo(() => {
    const map = new Map<string, number>();
    state.history.forEach((entry, index) => {
      const key = `${entry.category}:${entry.word}`;
      if (!map.has(key)) map.set(key, index);
    });
    return map;
  }, [state.history]);

  const list = useMemo(() => {
    const q = query.trim().toUpperCase().slice(0, 40);
    return WORDS.filter((w) => discovered.has(wordKey(w)))
      .filter((w) => category === "all" || w.category === category)
      .filter((w) => difficulty === "all" || difficultyOf(w.word) === difficulty)
      .filter(
        (w) =>
          !q ||
          w.word.includes(q) ||
          w.meaning.toUpperCase().includes(q) ||
          w.fact.toUpperCase().includes(q),
      )
      .sort((a, b) => {
        if (sort === "alpha") return a.word.localeCompare(b.word);
        if (sort === "difficulty") {
          const order = { easy: 0, medium: 1, hard: 2 };
          const diff = order[difficultyOf(a.word)] - order[difficultyOf(b.word)];
          return diff || a.word.localeCompare(b.word);
        }
        const ai = discoveredOrder.get(wordKey(a)) ?? Infinity;
        const bi = discoveredOrder.get(wordKey(b)) ?? Infinity;
        return ai - bi || a.word.localeCompare(b.word);
      });
  }, [category, difficulty, query, sort, discovered, discoveredOrder]);

  const hasFilters = category !== "all" || difficulty !== "all" || query !== "" || sort !== "alpha";

  const clearFilters = () => {
    setCategory("all");
    setDifficulty("all");
    setQuery("");
    setSort("alpha");
  };

  return (
    <PageShell
      title="Learning Library"
      subtitle={`${discovered.size} of ${WORDS.length} words discovered so far.`}
    >
      <div className="glass rounded-3xl p-5 space-y-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <label className="block flex-1">
            <span className="sr-only">Search discovered words</span>
            <div className="relative">
              <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground">
                🔎
              </span>
              <input
                value={query}
                maxLength={40}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search words, meanings or facts…"
                className="w-full rounded-2xl bg-card py-3 pl-10 pr-10 text-sm ring-1 ring-border focus:outline-none focus:ring-2 focus:ring-ring"
              />
              {query ? (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label="Clear search"
                >
                  ✕
                </button>
              ) : null}
            </div>
          </label>

          <div className="flex items-center gap-2">
            <label className="sr-only" htmlFor="sort-select">
              Sort by
            </label>
            <select
              id="sort-select"
              value={sort}
              onChange={(e) => setSort(e.target.value as SortMode)}
              className="rounded-2xl bg-card px-3 py-3 text-sm ring-1 ring-border focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="alpha">A–Z</option>
              <option value="discovered">Recently discovered</option>
              <option value="difficulty">Difficulty</option>
            </select>
            {hasFilters ? (
              <button
                type="button"
                onClick={clearFilters}
                className="press rounded-2xl bg-secondary px-3 py-3 text-sm font-bold text-secondary-foreground ring-1 ring-border"
              >
                Clear
              </button>
            ) : null}
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
            Category
          </p>
          <div className="flex flex-wrap gap-2">
            <Chip active={category === "all"} onClick={() => setCategory("all")} label="All" />
            {CATEGORIES.map((c) => (
              <Chip
                key={c.id}
                active={category === c.id}
                onClick={() => setCategory(c.id)}
                label={`${c.emoji} ${c.name}`}
              />
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
            Difficulty
          </p>
          <div className="flex flex-wrap gap-2">
            <Chip
              active={difficulty === "all"}
              onClick={() => setDifficulty("all")}
              label="All"
            />
            {(["easy", "medium", "hard"] as Difficulty[]).map((d) => (
              <Chip
                key={d}
                active={difficulty === d}
                onClick={() => setDifficulty(d)}
                label={DIFFICULTY_CONFIG[d].label}
              />
            ))}
          </div>
        </div>
      </div>

      {category !== "all" ? (
        <p className="mt-4 rounded-2xl bg-secondary/70 px-4 py-3 text-sm text-muted-foreground">
          {CATEGORY_MAP[category].blurb}
        </p>
      ) : null}

      <p className="mt-4 text-sm text-muted-foreground">
        {list.length} result{list.length === 1 ? "" : "s"}
        {query ? ` for “${query.trim()}”` : null}
      </p>

      {list.length === 0 ? (
        <div className="glass mt-5 rounded-3xl p-8 text-center">
          <p className="text-4xl">🔎</p>
          <h2 className="mt-3 font-display text-xl font-bold">Nothing here yet</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {hasFilters
              ? "Try clearing your filters or searching for something else."
              : "Words appear in your library once you have played them in a round."}
          </p>
          {hasFilters ? (
            <button
              type="button"
              onClick={clearFilters}
              className="press mt-5 inline-block rounded-2xl bg-primary px-6 py-3 font-bold text-primary-foreground"
            >
              Clear filters
            </button>
          ) : (
            <Link
              to="/play"
              className="press mt-5 inline-block rounded-2xl bg-primary px-6 py-3 font-bold text-primary-foreground"
            >
              Discover a word
            </Link>
          )}
        </div>
      ) : (
        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          {list.map((w) => (
            <article key={wordKey(w)} className="glass rounded-2xl p-5 animate-rise">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="font-display text-lg font-extrabold">
                  <Highlight text={w.word} query={query} />
                </h2>
                <span className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-bold text-secondary-foreground">
                  {CATEGORY_MAP[w.category].emoji} {CATEGORY_MAP[w.category].name}
                </span>
                <span className="rounded-full bg-accent/50 px-2.5 py-0.5 text-xs font-bold text-accent-foreground">
                  {DIFFICULTY_CONFIG[difficultyOf(w.word)].label}
                </span>
              </div>
              <p className="mt-2 text-sm">
                <strong>Meaning:</strong>{" "}
                <Highlight text={w.meaning} query={query} />
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                <strong>Fact:</strong>{" "}
                <Highlight text={w.fact} query={query} />
              </p>
            </article>
          ))}
        </div>
      )}
    </PageShell>
  );
}

function Chip({
  active,
  onClick,
  label,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "press rounded-full px-3 py-1.5 text-sm font-bold ring-1 transition-colors",
        active ? "bg-primary text-primary-foreground ring-primary" : "bg-card ring-border",
      )}
    >
      {label}
    </button>
  );
}

function Highlight({ text, query }: { text: string; query: string }) {
  const q = query.trim().toUpperCase();
  if (!q) return <>{text}</>;

  const parts: (string | ReactNode)[] = [];
  let remaining = text;
  let key = 0;

  while (remaining.length) {
    const index = remaining.toUpperCase().indexOf(q);
    if (index === -1) {
      parts.push(remaining);
      break;
    }
    if (index > 0) parts.push(remaining.slice(0, index));
    parts.push(
      <mark
        key={key++}
        className="rounded bg-primary/20 px-0.5 font-semibold text-primary"
      >
        {remaining.slice(index, index + q.length)}
      </mark>,
    );
    remaining = remaining.slice(index + q.length);
  }

  return <>{parts}</>;
}
