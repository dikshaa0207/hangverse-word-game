import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Award,
  BarChart3,
  Coins,
  Flame,
  Gamepad2,
  Lightbulb,
  Percent,
  Trophy,
  XCircle,
} from "lucide-react";
import { PageShell } from "@/components/hangverse/PageShell";
import { StatTile } from "@/components/hangverse/StatTile";
import { useHangVerse } from "@/lib/hangverse/store";

export const Route = createFileRoute("/statistics")({
  head: () => ({
    meta: [
      { title: "Statistics — Your HangVerse Performance" },
      {
        name: "description",
        content:
          "Track games played, wins, losses, win percentage, best score, highest streak, words solved, hints used and coins earned in HangVerse.",
      },
      { property: "og:title", content: "Statistics — Your HangVerse Performance" },
      {
        property: "og:description",
        content: "A full breakdown of your HangVerse results, streaks and coins.",
      },
    ],
  }),
  component: Statistics,
});

function Statistics() {
  const { state, hydrated } = useHangVerse();
  const s = hydrated ? state : { ...state, gamesPlayed: 0 };
  const winPct = s.gamesPlayed ? Math.round((s.gamesWon / s.gamesPlayed) * 100) : 0;

  return (
    <PageShell title="Statistics" subtitle="Every number is saved locally in your browser.">
      {s.gamesPlayed === 0 ? (
        <div className="glass rounded-3xl p-8 text-center">
          <p className="text-4xl">📊</p>
          <h2 className="mt-3 font-display text-xl font-bold">No rounds recorded yet</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Play your first round and your stats will start filling up instantly.
          </p>
          <Link
            to="/play"
            className="press mt-5 inline-block rounded-2xl bg-primary px-6 py-3 font-bold text-primary-foreground"
          >
            Start Game
          </Link>
        </div>
      ) : null}

      <div className="mt-2 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <StatTile label="Games played" value={s.gamesPlayed} icon={<Gamepad2 className="size-5" />} />
        <StatTile
          label="Games won"
          value={s.gamesWon}
          tone="success"
          icon={<Trophy className="size-5" />}
        />
        <StatTile
          label="Games lost"
          value={s.gamesLost}
          tone="destructive"
          icon={<XCircle className="size-5" />}
        />
        <StatTile label="Win percentage" value={`${winPct}%`} icon={<Percent className="size-5" />} />
        <StatTile label="Best score" value={s.bestScore} icon={<BarChart3 className="size-5" />} />
        <StatTile
          label="Highest streak"
          value={s.bestStreak}
          tone="destructive"
          icon={<Flame className="size-5" />}
        />
        <StatTile
          label="Total words solved"
          value={s.gamesWon}
          tone="accent"
          icon={<Award className="size-5" />}
        />
        <StatTile
          label="Total hints used"
          value={s.totalHintsUsed}
          tone="warning"
          icon={<Lightbulb className="size-5" />}
        />
        <StatTile
          label="Coins earned"
          value={s.coins}
          tone="warning"
          icon={<Coins className="size-5" />}
        />
      </div>

      <div className="mt-6 glass rounded-3xl p-5">
        <h2 className="font-display text-lg font-bold">Win rate</h2>
        <div className="mt-3 h-4 w-full overflow-hidden rounded-full bg-secondary">
          <div
            className="h-full rounded-full bg-primary transition-all duration-700"
            style={{ width: `${winPct}%` }}
          />
        </div>
        <p className="mt-2 text-sm text-muted-foreground">
          {s.gamesWon} wins out of {s.gamesPlayed} rounds · current streak {s.currentStreak} ·{" "}
          {s.discoveredKeys.length} unique words discovered.
        </p>
      </div>
    </PageShell>
  );
}
