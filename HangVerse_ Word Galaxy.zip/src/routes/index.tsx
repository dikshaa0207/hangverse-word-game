import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BarChart3,
  BookOpen,
  History,
  HelpCircle,
  Play,
  Trophy,
  User,
} from "lucide-react";
import { PageShell } from "@/components/hangverse/PageShell";
import { Doodle, FloatingDoodle } from "@/components/hangverse/Doodle";
import { QuoteCard } from "@/components/hangverse/QuoteCard";
import { useHangVerse } from "@/lib/hangverse/store";
import { WORDS, CATEGORIES } from "@/lib/hangverse/words";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "HangVerse — Guess. Learn. Achieve." },
      {
        name: "description",
        content:
          "HangVerse is an unlimited hangman word game with categories, hints, achievements, streaks and a learning library of word meanings and facts.",
      },
      { property: "og:title", content: "HangVerse — Guess. Learn. Achieve." },
      {
        property: "og:description",
        content:
          "Play unlimited hangman across 10 categories, earn coins, unlock achievements and learn a new word every round.",
      },
    ],
  }),
  component: Home,
});

const MENU = [
  {
    to: "/how-to-play",
    label: "How to Play",
    icon: HelpCircle,
    doodle: "bubble" as const,
    tone: "text-primary",
    tilt: "tilt-1",
  },
  {
    to: "/statistics",
    label: "Statistics",
    icon: BarChart3,
    doodle: "check" as const,
    tone: "text-success-foreground",
    tilt: "tilt-2",
  },
  {
    to: "/achievements",
    label: "Achievements",
    icon: Trophy,
    doodle: "crown" as const,
    tone: "text-warning-foreground",
    tilt: "tilt-1",
  },
  {
    to: "/library",
    label: "Learning Library",
    icon: BookOpen,
    doodle: "book" as const,
    tone: "text-accent-foreground",
    tilt: "tilt-3",
  },
  {
    to: "/history",
    label: "Game History",
    icon: History,
    doodle: "pencil" as const,
    tone: "text-muted-foreground",
    tilt: "tilt-2",
  },
  {
    to: "/play",
    label: "Start a Round",
    icon: Play,
    doodle: "star" as const,
    tone: "text-primary",
    tilt: "tilt-1",
  },
] as const;

function Home() {
  const { state, hydrated } = useHangVerse();

  return (
    <PageShell>
      {/* ---------------- Hero ---------------- */}
      <section className="paper relative overflow-hidden rounded-[2rem] px-6 py-14 text-center sm:px-12 sm:py-20">
        <FloatingDoodle
          name="cloud"
          size={64}
          className="left-4 top-6 text-primary/40 sm:left-10"
          motion="float"
        />
        <FloatingDoodle
          name="star"
          size={34}
          className="right-8 top-10 text-warning/70"
          motion="sway"
          delay={0.8}
        />
        <FloatingDoodle
          name="heart"
          size={30}
          className="left-10 bottom-10 text-blush"
          motion="twinkle"
          delay={1.4}
        />
        <FloatingDoodle
          name="flower"
          size={44}
          className="right-6 bottom-8 text-lavender sm:right-14"
          motion="sway"
          delay={0.4}
        />
        <Doodle
          name="squiggle"
          size={90}
          className="absolute left-1/2 top-3 -translate-x-1/2 text-primary/25"
          strokeWidth={2}
        />

        <div className="relative animate-rise">
          <span className="inline-flex items-center gap-2 rounded-full bg-secondary/80 px-4 py-1.5 text-sm font-bold text-secondary-foreground">
            <Doodle name="sparkle" size={16} strokeWidth={2.8} /> {WORDS.length} words ·{" "}
            {CATEGORIES.length} categories
          </span>

          <h1 className="relative mx-auto mt-6 max-w-3xl font-display text-4xl font-extrabold leading-tight sm:text-6xl">
            Welcome to <span className="gradient-text">HangVerse</span>{" "}
            <span className="text-warning-foreground">✦</span>
          </h1>

          <p className="hand mt-3 text-3xl font-bold text-primary sm:text-4xl">
            Guess. Learn. Achieve.
          </p>
          <p className="mx-auto mt-3 max-w-lg text-sm text-muted-foreground sm:text-base">
            Turn every guess into a little victory.
          </p>

          <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
            <Link
              to="/play"
              className="group inline-flex items-center gap-2 rounded-full bg-primary px-8 py-4 font-display text-lg font-extrabold text-primary-foreground shadow-[var(--shadow-lift)] transition-all duration-200 hover:-translate-y-1 hover:scale-[1.03] hover:shadow-[var(--shadow-lift)] active:translate-y-0 active:scale-100"
            >
              <Play className="size-5 transition-transform group-hover:scale-110" aria-hidden />
              Start Playing
            </Link>
            <Link
              to="/library"
              className="press inline-flex items-center gap-2 rounded-full bg-card px-7 py-4 font-display text-lg font-bold ring-1 ring-border"
            >
              <BookOpen className="size-5" aria-hidden />
              Explore HangVerse
            </Link>
          </div>

          <Link
            to="/profile"
            className="press mt-6 inline-flex items-center gap-2 rounded-full bg-butter/70 px-5 py-2 text-sm font-bold text-warning-foreground"
          >
            <User className="size-4" aria-hidden />
            {hydrated ? state.playerName : "Player"} · {hydrated ? state.coins : 0} coins
          </Link>
        </div>
      </section>

      {/* ---------------- Quote ---------------- */}
      <div className="mx-auto mt-10 max-w-xl">
        <QuoteCard />
      </div>

      {/* ---------------- Menu cards ---------------- */}
      <section className="mt-12">
        <div className="relative mb-6 text-center">
          <h2 className="font-display text-2xl font-extrabold">Your little corners</h2>
          <p className="hand text-xl text-muted-foreground">wander wherever you like ✦</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {MENU.map(({ to, label, icon: Icon, doodle, tone, tilt }, i) => (
            <Link
              key={to}
              to={to}
              className={`paper group relative overflow-hidden rounded-3xl px-5 py-6 transition-transform duration-200 hover:-translate-y-1 hover:rotate-0 ${i % 2 === 0 ? tilt : ""}`}
            >
              <Doodle
                name={doodle}
                size={72}
                strokeWidth={2}
                className={`absolute -right-3 -top-3 opacity-15 ${tone}`}
              />
              <span className={`inline-grid size-11 place-items-center rounded-2xl bg-secondary/70 ${tone}`}>
                <Icon className="size-5" aria-hidden />
              </span>
              <h3 className="mt-3 font-display text-lg font-bold">{label}</h3>
              <p className="hand text-xl text-muted-foreground">
                {DESCRIPTIONS[label]}
              </p>
            </Link>
          ))}
        </div>
      </section>

      {/* ---------------- Why cards ---------------- */}
      <section className="mt-12 grid gap-5 sm:grid-cols-3">
        {[
          {
            title: "Learn as you play",
            body: "Every word ends with its meaning plus an interesting fact you can actually remember.",
            doodle: "book" as const,
            tone: "text-accent-foreground",
          },
          {
            title: "Never the same word",
            body: "Words are drawn from a rotating pool, so nothing repeats until the pool runs out.",
            doodle: "arrow" as const,
            tone: "text-primary",
          },
          {
            title: "Progress that sticks",
            body: "Coins, streaks, achievements and history are saved right in your browser.",
            doodle: "check" as const,
            tone: "text-success-foreground",
          },
        ].map((c, i) => (
          <div
            key={c.title}
            className={`paper-cream animate-rise relative rounded-3xl p-6 ${i === 1 ? "tilt-2" : "tilt-1"}`}
          >
            <Doodle name={c.doodle} size={34} strokeWidth={2.2} className={c.tone} />
            <h2 className="mt-3 font-display text-lg font-bold">{c.title}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{c.body}</p>
          </div>
        ))}
      </section>
    </PageShell>
  );
}

const DESCRIPTIONS: Record<string, string> = {
  "How to Play": "the tiny rulebook",
  Statistics: "your numbers, prettily",
  Achievements: "shiny things to collect",
  "Learning Library": "words worth keeping",
  "Game History": "every round you played",
  "Start a Round": "jump straight in",
};
