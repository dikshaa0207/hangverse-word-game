import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/hangverse/PageShell";
import { ACHIEVEMENTS } from "@/lib/hangverse/achievements";
import { useHangVerse } from "@/lib/hangverse/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/achievements")({
  head: () => ({
    meta: [
      { title: "Achievements — HangVerse Badges" },
      {
        name: "description",
        content:
          "Unlock HangVerse badges like First Win, Word Master, Perfect Guess, Hint Master, Category Explorer and Hard Mode Champion.",
      },
      { property: "og:title", content: "Achievements — HangVerse Badges" },
      {
        property: "og:description",
        content: "Track which HangVerse achievements you have unlocked and what is still left.",
      },
    ],
  }),
  component: AchievementsPage,
});

function AchievementsPage() {
  const { state, hydrated } = useHangVerse();
  const unlockedCount = hydrated ? Object.keys(state.achievements).length : 0;

  return (
    <PageShell
      title="Achievements"
      subtitle={`${unlockedCount} of ${ACHIEVEMENTS.length} unlocked`}
    >
      <div className="glass mb-6 rounded-3xl p-5">
        <div className="h-4 w-full overflow-hidden rounded-full bg-secondary">
          <div
            className="h-full rounded-full bg-primary transition-all duration-700"
            style={{ width: `${(unlockedCount / ACHIEVEMENTS.length) * 100}%` }}
          />
        </div>
        <p className="mt-2 text-sm text-muted-foreground">
          Badges unlock automatically the moment you meet their condition.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {ACHIEVEMENTS.map((a) => {
          const at = hydrated ? state.achievements[a.id] : undefined;
          const unlocked = Boolean(at);
          return (
            <div
              key={a.id}
              className={cn(
                "rounded-2xl p-5 ring-1 transition-all animate-rise",
                unlocked
                  ? "glass ring-primary/40"
                  : "bg-card/40 ring-border opacity-70 grayscale",
              )}
            >
              <div className="flex items-start gap-3">
                <span
                  className={cn(
                    "grid size-12 shrink-0 place-items-center rounded-2xl text-2xl",
                    unlocked ? "bg-accent/50" : "bg-secondary",
                  )}
                >
                  {unlocked ? a.emoji : "🔒"}
                </span>
                <div className="min-w-0">
                  <h2 className="font-display font-bold">{a.name}</h2>
                  <p className="text-sm text-muted-foreground">{a.description}</p>
                  {unlocked && at ? (
                    <p className="mt-1 text-xs font-semibold text-primary">
                      Unlocked {new Date(at).toLocaleDateString()}
                    </p>
                  ) : null}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <Link
        to="/play"
        className="press mt-6 inline-block rounded-2xl bg-primary px-6 py-3 font-display font-extrabold text-primary-foreground shadow-md"
      >
        Chase the next badge
      </Link>
    </PageShell>
  );
}
