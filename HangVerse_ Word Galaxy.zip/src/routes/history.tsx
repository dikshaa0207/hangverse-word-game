import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/hangverse/PageShell";
import { useHangVerse } from "@/lib/hangverse/store";
import { CATEGORY_MAP, DIFFICULTY_CONFIG } from "@/lib/hangverse/words";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/history")({
  head: () => ({
    meta: [
      { title: "Game History — Your Past HangVerse Rounds" },
      {
        name: "description",
        content:
          "Review your previous HangVerse rounds with the word, category, difficulty, result, score and hints used.",
      },
      { property: "og:title", content: "Game History — Your Past HangVerse Rounds" },
      {
        property: "og:description",
        content: "A log of your last HangVerse rounds and how each one went.",
      },
    ],
  }),
  component: HistoryPage,
});

function HistoryPage() {
  const { state, hydrated } = useHangVerse();
  const history = hydrated ? state.history : [];

  return (
    <PageShell title="Game History" subtitle="Your most recent 60 rounds.">
      {history.length === 0 ? (
        <div className="glass rounded-3xl p-8 text-center">
          <p className="text-4xl">🕹️</p>
          <h2 className="mt-3 font-display text-xl font-bold">No rounds played yet</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Finish a round and it will show up here automatically.
          </p>
          <Link
            to="/play"
            className="press mt-5 inline-block rounded-2xl bg-primary px-6 py-3 font-bold text-primary-foreground"
          >
            Play a round
          </Link>
        </div>
      ) : (
        <ul className="space-y-3">
          {history.map((h) => (
            <li
              key={h.id}
              className="glass grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-2xl p-4 animate-rise sm:flex sm:justify-between"
            >
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-display text-lg font-extrabold">{h.word}</span>
                  <span className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-bold text-secondary-foreground">
                    {CATEGORY_MAP[h.category].emoji} {CATEGORY_MAP[h.category].name}
                  </span>
                  <span className="rounded-full bg-accent/50 px-2.5 py-0.5 text-xs font-bold text-accent-foreground">
                    {DIFFICULTY_CONFIG[h.difficulty].label}
                  </span>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  {new Date(h.playedAt).toLocaleString()} · {h.hintsUsed} hint
                  {h.hintsUsed === 1 ? "" : "s"} · {h.wrongGuesses} wrong
                </p>
              </div>
              <div className="text-right">
                <span
                  className={cn(
                    "rounded-full px-3 py-1 text-xs font-extrabold uppercase",
                    h.result === "won"
                      ? "bg-success/25 text-success-foreground"
                      : "bg-destructive/15 text-destructive",
                  )}
                >
                  {h.result}
                </span>
                <p className="mt-1 font-display text-lg font-extrabold">{h.score} pts</p>
              </div>
            </li>
          ))}
        </ul>
      )}
    </PageShell>
  );
}
