import { EXTRA_WORDS } from "./words-extra";

export type Difficulty = "easy" | "medium" | "hard";

export type CategoryId =
  | "technology"
  | "programming"
  | "science"
  | "animals"
  | "food"
  | "movies"
  | "sports"
  | "countries"
  | "general"
  | "education";

export interface WordEntry {
  word: string;
  category: CategoryId;
  hint: string;
  meaning: string;
  fact: string;
}

export interface CategoryInfo {
  id: CategoryId;
  name: string;
  emoji: string;
  blurb: string;
}

export const CATEGORIES: CategoryInfo[] = [
  {
    id: "technology",
    name: "Technology",
    emoji: "💡",
    blurb: "Devices, networks and the machinery of the digital world.",
  },
  {
    id: "programming",
    name: "Programming",
    emoji: "⌨️",
    blurb: "Languages, concepts and tools that developers live in.",
  },
  {
    id: "science",
    name: "Science",
    emoji: "🔬",
    blurb: "Physics, chemistry, biology and the curious in between.",
  },
  {
    id: "animals",
    name: "Animals",
    emoji: "🦊",
    blurb: "Creatures of land, sea and sky.",
  },
  { id: "food", name: "Food", emoji: "🍜", blurb: "Dishes and ingredients from around the globe." },
  { id: "movies", name: "Movies", emoji: "🎬", blurb: "Cinema classics and blockbuster words." },
  { id: "sports", name: "Sports", emoji: "🏅", blurb: "Games, gear and glory." },
  { id: "countries", name: "Countries", emoji: "🌍", blurb: "Nations and the places that shape us." },
  {
    id: "general",
    name: "General Knowledge",
    emoji: "🧠",
    blurb: "A little bit of everything worth knowing.",
  },
  {
    id: "education",
    name: "Education",
    emoji: "🎓",
    blurb: "Learning, schooling and academic life.",
  },
];

export const CATEGORY_MAP: Record<CategoryId, CategoryInfo> = CATEGORIES.reduce(
  (acc, c) => {
    acc[c.id] = c;
    return acc;
  },
  {} as Record<CategoryId, CategoryInfo>,
);

export const WORDS: WordEntry[] = [
  // ---------------- Technology ----------------
  {
    word: "ROUTER",
    category: "technology",
    hint: "It hands out Wi-Fi to every device in your home.",
    meaning: "A device that forwards data packets between computer networks.",
    fact: "The first commercial router shipped in 1986 and cost more than a car.",
  },
  {
    word: "CLOUD",
    category: "technology",
    hint: "Your files live 'up there', but really on someone else's computer.",
    meaning: "On-demand computing resources delivered over the internet.",
    fact: "Cloud data centres now consume around 1-2% of the world's electricity.",
  },
  {
    word: "ROBOT",
    category: "technology",
    hint: "A machine that can carry out tasks automatically.",
    meaning: "A programmable machine capable of performing actions on its own.",
    fact: "The word comes from the Czech 'robota', meaning forced labour.",
  },
  {
    word: "FIREWALL",
    category: "technology",
    hint: "A digital gatekeeper that blocks unwanted traffic.",
    meaning: "A security system that monitors and filters network traffic.",
    fact: "The name borrows from building design, where firewalls stop flames spreading.",
  },
  {
    word: "BLUETOOTH",
    category: "technology",
    hint: "Short-range wireless named after a Viking king.",
    meaning: "A wireless standard for exchanging data over short distances.",
    fact: "Its logo combines the runes for Harald Bluetooth's initials.",
  },
  {
    word: "SATELLITE",
    category: "technology",
    hint: "It orbits above and beams signals down.",
    meaning: "An object placed in orbit to relay communication or collect data.",
    fact: "Sputnik 1, launched in 1957, only transmitted beeps for 21 days.",
  },
  {
    word: "KEYBOARD",
    category: "technology",
    hint: "QWERTY lives here.",
    meaning: "An input device with keys used to enter characters and commands.",
    fact: "The QWERTY layout was designed for typewriters, not for speed.",
  },
  {
    word: "PIXEL",
    category: "technology",
    hint: "The tiniest dot on your screen.",
    meaning: "The smallest addressable element of a digital image or display.",
    fact: "The word is short for 'picture element'.",
  },
  {
    word: "ENCRYPTION",
    category: "technology",
    hint: "It scrambles messages so only the right person can read them.",
    meaning: "The process of converting information into an unreadable code.",
    fact: "Julius Caesar used a simple letter-shift cipher to protect messages.",
  },
  {
    word: "BROWSER",
    category: "technology",
    hint: "The window you use to reach the web.",
    meaning: "Software used to access and display web pages.",
    fact: "The first browser, WorldWideWeb, was also a page editor.",
  },

  // ---------------- Programming ----------------
  {
    word: "ARRAY",
    category: "programming",
    hint: "An ordered list where counting starts at zero.",
    meaning: "A data structure storing elements in indexed positions.",
    fact: "Zero-based indexing spread widely because of the C language.",
  },
  {
    word: "LOOP",
    category: "programming",
    hint: "It repeats code until a condition ends it.",
    meaning: "A control structure that repeats a block of instructions.",
    fact: "An unintentional endless one is called an infinite loop.",
  },
  {
    word: "PYTHON",
    category: "programming",
    hint: "A language named after a comedy troupe, not the snake.",
    meaning: "A high-level programming language known for readable syntax.",
    fact: "It is named after Monty Python's Flying Circus.",
  },
  {
    word: "FUNCTION",
    category: "programming",
    hint: "A reusable block that may take inputs and return a value.",
    meaning: "A named unit of code that performs a specific task.",
    fact: "Pure ones always return the same output for the same input.",
  },
  {
    word: "DEBUGGER",
    category: "programming",
    hint: "A tool that lets you pause code and inspect it.",
    meaning: "Software used to test and step through programs to find errors.",
    fact: "The first real 'bug' was a moth found inside a Harvard computer in 1947.",
  },
  {
    word: "RECURSION",
    category: "programming",
    hint: "A function that calls itself. See: this hint.",
    meaning: "A technique where a function solves a problem by calling itself.",
    fact: "Every recursive solution can, in theory, be rewritten with a loop.",
  },
  {
    word: "COMPILER",
    category: "programming",
    hint: "It translates source code into machine code.",
    meaning: "A program that converts code from one language into another.",
    fact: "Grace Hopper built the first compiler-like tool, A-0, in 1952.",
  },
  {
    word: "VARIABLE",
    category: "programming",
    hint: "A labelled box for storing a value.",
    meaning: "A named storage location whose value can change during execution.",
    fact: "Naming them well is famously one of computing's hardest problems.",
  },
  {
    word: "SYNTAX",
    category: "programming",
    hint: "Break these rules and the code won't run.",
    meaning: "The set of rules defining valid statements in a language.",
    fact: "A missing semicolon has crashed more builds than any virus.",
  },
  {
    word: "ALGORITHM",
    category: "programming",
    hint: "A step-by-step recipe for solving a problem.",
    meaning: "A finite sequence of instructions to complete a task.",
    fact: "The word honours the Persian scholar al-Khwarizmi.",
  },

  // ---------------- Science ----------------
  {
    word: "ATOM",
    category: "science",
    hint: "The smallest unit of an element.",
    meaning: "A particle consisting of a nucleus surrounded by electrons.",
    fact: "Atoms are mostly empty space — the nucleus is tiny by comparison.",
  },
  {
    word: "COMET",
    category: "science",
    hint: "An icy visitor with a glowing tail.",
    meaning: "An icy body that releases gas and dust when near the Sun.",
    fact: "Halley's Comet returns roughly every 76 years.",
  },
  {
    word: "GRAVITY",
    category: "science",
    hint: "The reason apples fall down, not up.",
    meaning: "The force of attraction between masses.",
    fact: "You'd weigh about one sixth as much standing on the Moon.",
  },
  {
    word: "NEURON",
    category: "science",
    hint: "The brain's messaging cell.",
    meaning: "A cell that transmits electrical and chemical signals.",
    fact: "The human brain holds roughly 86 billion of them.",
  },
  {
    word: "ENZYME",
    category: "science",
    hint: "A biological catalyst that speeds up reactions.",
    meaning: "A protein that accelerates chemical reactions in living things.",
    fact: "Most stop working if the temperature climbs too high.",
  },
  {
    word: "MOLECULE",
    category: "science",
    hint: "Two or more atoms bonded together.",
    meaning: "A group of atoms bonded to form the smallest unit of a compound.",
    fact: "A single drop of water holds over a sextillion of them.",
  },
  {
    word: "ECLIPSE",
    category: "science",
    hint: "When one body hides another in the sky.",
    meaning: "An event where one celestial body blocks light from another.",
    fact: "A total solar eclipse happens somewhere on Earth roughly every 18 months.",
  },
  {
    word: "PHOTOSYNTHESIS",
    category: "science",
    hint: "How green leaves turn sunlight into food.",
    meaning: "The process plants use to convert light into chemical energy.",
    fact: "It produces almost all of the oxygen we breathe.",
  },
  {
    word: "VOLCANO",
    category: "science",
    hint: "A mountain that can erupt.",
    meaning: "An opening in Earth's crust through which lava and gas escape.",
    fact: "Most of Earth's volcanic activity happens underwater.",
  },
  {
    word: "GALAXY",
    category: "science",
    hint: "A huge system of stars, gas and dust.",
    meaning: "A gravitationally bound collection of stars and interstellar matter.",
    fact: "The observable universe may contain two trillion of them.",
  },

  // ---------------- Animals ----------------
  {
    word: "OTTER",
    category: "animals",
    hint: "A playful river swimmer that floats on its back.",
    meaning: "A semi-aquatic mammal known for its dense fur and play.",
    fact: "Sea otters hold hands while sleeping so they don't drift apart.",
  },
  {
    word: "PANDA",
    category: "animals",
    hint: "Black and white, obsessed with bamboo.",
    meaning: "A bear native to China that feeds almost entirely on bamboo.",
    fact: "A panda can eat up to 38 kg of bamboo in a single day.",
  },
  {
    word: "FALCON",
    category: "animals",
    hint: "The fastest animal alive, in a dive.",
    meaning: "A bird of prey with pointed wings and rapid flight.",
    fact: "A peregrine falcon can dive at over 380 km/h.",
  },
  {
    word: "DOLPHIN",
    category: "animals",
    hint: "A clever sea mammal that talks in clicks.",
    meaning: "A highly intelligent marine mammal in the cetacean family.",
    fact: "Dolphins sleep with one half of the brain awake at a time.",
  },
  {
    word: "OCTOPUS",
    category: "animals",
    hint: "Eight arms and a talent for escape.",
    meaning: "A soft-bodied sea creature with eight limbs and no skeleton.",
    fact: "It has three hearts and blue blood.",
  },
  {
    word: "CHEETAH",
    category: "animals",
    hint: "Spotted sprinter of the savanna.",
    meaning: "The fastest land animal, native to Africa and parts of Iran.",
    fact: "It can accelerate from 0 to 100 km/h in about three seconds.",
  },
  {
    word: "PENGUIN",
    category: "animals",
    hint: "A bird in a tuxedo that swims instead of flies.",
    meaning: "A flightless seabird adapted to swimming in cold waters.",
    fact: "Emperor penguins can dive deeper than 500 metres.",
  },
  {
    word: "CHAMELEON",
    category: "animals",
    hint: "It changes colour and aims its eyes separately.",
    meaning: "A lizard able to change skin colour and move each eye independently.",
    fact: "Colour change signals mood and temperature more than camouflage.",
  },
  {
    word: "KANGAROO",
    category: "animals",
    hint: "It hops and carries its baby in a pouch.",
    meaning: "A large marsupial native to Australia.",
    fact: "It cannot walk backwards easily because of its thick tail.",
  },
  {
    word: "HEDGEHOG",
    category: "animals",
    hint: "A small spiny mammal that rolls into a ball.",
    meaning: "A nocturnal mammal covered in protective spines.",
    fact: "Each one carries roughly 5,000 to 7,000 spines.",
  },

  // ---------------- Food ----------------
  {
    word: "MANGO",
    category: "food",
    hint: "The 'king of fruits' in South Asia.",
    meaning: "A sweet tropical stone fruit with golden flesh.",
    fact: "India grows almost half the world's mangoes.",
  },
  {
    word: "SUSHI",
    category: "food",
    hint: "Vinegared rice, often with raw fish.",
    meaning: "A Japanese dish of seasoned rice served with fish or vegetables.",
    fact: "It began as a way of preserving fish in fermented rice.",
  },
  {
    word: "PASTA",
    category: "food",
    hint: "Comes in shapes like penne and fusilli.",
    meaning: "An Italian staple made from wheat dough.",
    fact: "There are more than 350 recognised pasta shapes.",
  },
  {
    word: "PANCAKE",
    category: "food",
    hint: "Flat, fluffy and flipped in a pan.",
    meaning: "A thin flat cake cooked on a griddle from batter.",
    fact: "Some cultures have eaten them for over 30,000 years.",
  },
  {
    word: "CHOCOLATE",
    category: "food",
    hint: "Made from cacao beans and hard to resist.",
    meaning: "A sweet food made from roasted and ground cacao seeds.",
    fact: "The Aztecs served it as a bitter drink, not a sweet.",
  },
  {
    word: "BIRYANI",
    category: "food",
    hint: "A layered spiced rice dish from South Asia.",
    meaning: "A rice dish cooked with spices, meat or vegetables.",
    fact: "Nearly every Indian city claims its own signature version.",
  },
  {
    word: "AVOCADO",
    category: "food",
    hint: "Green, creamy, famous on toast.",
    meaning: "A fruit with buttery flesh and a large single seed.",
    fact: "Botanically it is a single-seeded berry.",
  },
  {
    word: "CINNAMON",
    category: "food",
    hint: "A warm spice made from tree bark.",
    meaning: "A spice obtained from the inner bark of certain trees.",
    fact: "It was once valued more highly than gold.",
  },
  {
    word: "NOODLE",
    category: "food",
    hint: "Long strands slurped from a bowl.",
    meaning: "A strip or string of dough, usually boiled.",
    fact: "A 4,000-year-old bowl of noodles was unearthed in China.",
  },
  {
    word: "PINEAPPLE",
    category: "food",
    hint: "Spiky outside, tropical and tangy inside.",
    meaning: "A tropical fruit with a rough skin and sweet yellow flesh.",
    fact: "It takes about two years for one plant to grow a single fruit.",
  },

  // ---------------- Movies ----------------
  {
    word: "ACTOR",
    category: "movies",
    hint: "The person delivering the lines on screen.",
    meaning: "A performer who portrays a character in a film or play.",
    fact: "Early silent film actors were often uncredited on purpose.",
  },
  {
    word: "SCRIPT",
    category: "movies",
    hint: "The written blueprint of a film.",
    meaning: "The written text containing dialogue and directions for a film.",
    fact: "One script page roughly equals one minute of screen time.",
  },
  {
    word: "TRAILER",
    category: "movies",
    hint: "A short preview shown before release.",
    meaning: "A promotional clip advertising an upcoming film.",
    fact: "They were originally shown after the movie, hence the name.",
  },
  {
    word: "ANIMATION",
    category: "movies",
    hint: "Bringing drawings or models to life frame by frame.",
    meaning: "The technique of creating motion from a sequence of images.",
    fact: "Traditional animation runs at 24 frames per second.",
  },
  {
    word: "DIRECTOR",
    category: "movies",
    hint: "The person who shouts 'Action!'.",
    meaning: "The creative lead who guides a film's production.",
    fact: "The clapperboard exists to sync picture with sound.",
  },
  {
    word: "SEQUEL",
    category: "movies",
    hint: "The follow-up that continues the story.",
    meaning: "A film that continues the narrative of an earlier one.",
    fact: "A story set before the original is a prequel instead.",
  },
  {
    word: "CINEMA",
    category: "movies",
    hint: "The place with the big screen and popcorn.",
    meaning: "A theatre where films are shown, or the film art form.",
    fact: "The Lumière brothers held the first public screening in 1895.",
  },
  {
    word: "SOUNDTRACK",
    category: "movies",
    hint: "The music that makes the scene hit harder.",
    meaning: "The recorded music accompanying a film.",
    fact: "Silent films still had live pianists playing along.",
  },
  {
    word: "THRILLER",
    category: "movies",
    hint: "A genre built on suspense and tension.",
    meaning: "A genre designed to keep the audience on edge.",
    fact: "Hitchcock called suspense the bomb under the table.",
  },
  {
    word: "SCREENPLAY",
    category: "movies",
    hint: "Formal name for a movie's written script.",
    meaning: "A script written specifically for a film production.",
    fact: "Standard formatting is so strict it has its own software.",
  },

  // ---------------- Sports ----------------
  {
    word: "GOAL",
    category: "sports",
    hint: "What every striker chases.",
    meaning: "A score made by getting the ball into the opponent's net.",
    fact: "Football's goal nets were invented in 1891.",
  },
  {
    word: "RUGBY",
    category: "sports",
    hint: "An oval ball, scrums and tackles.",
    meaning: "A contact team sport played with an oval ball.",
    fact: "It is named after Rugby School in England.",
  },
  {
    word: "TENNIS",
    category: "sports",
    hint: "Love means zero here.",
    meaning: "A racket sport played across a net, singly or in pairs.",
    fact: "Wimbledon still requires players to wear almost all white.",
  },
  {
    word: "MARATHON",
    category: "sports",
    hint: "A 42.195 km test of endurance.",
    meaning: "A long-distance running race of 42.195 kilometres.",
    fact: "The distance was fixed in 1908 to suit the royal viewing box.",
  },
  {
    word: "CRICKET",
    category: "sports",
    hint: "Bats, wickets and overs.",
    meaning: "A bat-and-ball sport played between two teams of eleven.",
    fact: "The longest Test match lasted twelve days and still had no winner.",
  },
  {
    word: "OLYMPICS",
    category: "sports",
    hint: "Held every four years with five rings.",
    meaning: "An international multi-sport event held every four years.",
    fact: "The five rings represent the inhabited continents.",
  },
  {
    word: "BADMINTON",
    category: "sports",
    hint: "Played with a shuttlecock.",
    meaning: "A racket sport played by hitting a shuttlecock over a net.",
    fact: "A smashed shuttlecock can exceed 400 km/h.",
  },
  {
    word: "SWIMMING",
    category: "sports",
    hint: "Freestyle, butterfly and backstroke.",
    meaning: "The sport of propelling yourself through water.",
    fact: "It has featured in every modern Olympic Games since 1896.",
  },
  {
    word: "HOCKEY",
    category: "sports",
    hint: "Played with sticks on grass or ice.",
    meaning: "A team sport where players hit a ball or puck with sticks.",
    fact: "Ice hockey pucks are frozen before games to stop them bouncing.",
  },
  {
    word: "REFEREE",
    category: "sports",
    hint: "The one with the whistle and the final word.",
    meaning: "An official who enforces the rules during a match.",
    fact: "Red and yellow cards were inspired by traffic lights.",
  },

  // ---------------- Countries ----------------
  {
    word: "JAPAN",
    category: "countries",
    hint: "The land of the rising sun.",
    meaning: "An island nation in East Asia.",
    fact: "It is made up of nearly 14,000 islands.",
  },
  {
    word: "BRAZIL",
    category: "countries",
    hint: "Home of the Amazon and samba.",
    meaning: "The largest country in South America.",
    fact: "It contains about 60% of the Amazon rainforest.",
  },
  {
    word: "CANADA",
    category: "countries",
    hint: "Maple leaf on the flag.",
    meaning: "A North American country and the world's second largest by area.",
    fact: "It has more lakes than the rest of the world combined.",
  },
  {
    word: "EGYPT",
    category: "countries",
    hint: "Pyramids and the Nile.",
    meaning: "A country linking northeast Africa with the Middle East.",
    fact: "The Great Pyramid stood as the tallest structure for 3,800 years.",
  },
  {
    word: "NORWAY",
    category: "countries",
    hint: "Fjords and the northern lights.",
    meaning: "A Nordic country in northern Europe.",
    fact: "Parts of it see the sun never set for weeks in summer.",
  },
  {
    word: "AUSTRALIA",
    category: "countries",
    hint: "A country that is also a continent.",
    meaning: "A country comprising the mainland, Tasmania and smaller islands.",
    fact: "It is home to the world's largest coral reef system.",
  },
  {
    word: "PORTUGAL",
    category: "countries",
    hint: "Westernmost country of mainland Europe.",
    meaning: "A country on the Iberian Peninsula bordering Spain.",
    fact: "It produces roughly half the world's cork.",
  },
  {
    word: "MOROCCO",
    category: "countries",
    hint: "Sahara dunes and blue-painted towns.",
    meaning: "A North African country on the Atlantic and Mediterranean.",
    fact: "The city of Chefchaouen is painted almost entirely blue.",
  },
  {
    word: "SINGAPORE",
    category: "countries",
    hint: "A tiny island city-state in Southeast Asia.",
    meaning: "A sovereign island city-state near the Malay Peninsula.",
    fact: "It has four official languages.",
  },
  {
    word: "ICELAND",
    category: "countries",
    hint: "Volcanoes, geysers and glaciers.",
    meaning: "A Nordic island nation in the North Atlantic.",
    fact: "Nearly all of its electricity comes from renewable sources.",
  },

  // ---------------- General Knowledge ----------------
  {
    word: "COMPASS",
    category: "general",
    hint: "It always points you north.",
    meaning: "An instrument used for navigation showing direction.",
    fact: "The earliest ones were used for fortune-telling, not travel.",
  },
  {
    word: "MUSEUM",
    category: "general",
    hint: "Where history is put on display.",
    meaning: "A building where objects of cultural interest are exhibited.",
    fact: "The Louvre was originally a fortress, then a royal palace.",
  },
  {
    word: "ORIGAMI",
    category: "general",
    hint: "The Japanese art of folding paper.",
    meaning: "The art of creating shapes by folding paper without cutting.",
    fact: "Engineers use its folding maths to pack solar panels for space.",
  },
  {
    word: "CURRENCY",
    category: "general",
    hint: "What you pay with, country by country.",
    meaning: "A system of money in general use in a particular country.",
    fact: "Some countries print notes on plastic polymer, not paper.",
  },
  {
    word: "DEMOCRACY",
    category: "general",
    hint: "Government chosen by the people.",
    meaning: "A system of government where citizens vote for representation.",
    fact: "The word comes from Greek 'demos' (people) and 'kratos' (power).",
  },
  {
    word: "LIGHTHOUSE",
    category: "general",
    hint: "A tower that warns ships at night.",
    meaning: "A tower with a beacon light that guides ships.",
    fact: "The Pharos of Alexandria was one of the seven ancient wonders.",
  },
  {
    word: "CALENDAR",
    category: "general",
    hint: "It organises days into months.",
    meaning: "A system for organising days for social and religious purposes.",
    fact: "Ten days were skipped in 1582 to switch to the Gregorian system.",
  },
  {
    word: "PUZZLE",
    category: "general",
    hint: "A problem designed to test your wits.",
    meaning: "A game or problem that tests ingenuity or knowledge.",
    fact: "Jigsaw puzzles began as educational maps cut into pieces.",
  },
  {
    word: "VOLUNTEER",
    category: "general",
    hint: "Someone who helps without being paid.",
    meaning: "A person who freely offers to take part in a task.",
    fact: "Volunteering is linked to measurably lower stress levels.",
  },
  {
    word: "MARATHON",
    category: "general",
    hint: "Named after a Greek battle and a long run.",
    meaning: "A long endurance event, literally or figuratively.",
    fact: "Legend says a messenger ran from Marathon to Athens with news of victory.",
  },

  // ---------------- Education ----------------
  {
    word: "EXAM",
    category: "education",
    hint: "The thing students revise all night for.",
    meaning: "A formal test of knowledge or ability.",
    fact: "Standardised exams were first used in imperial China.",
  },
  {
    word: "THESIS",
    category: "education",
    hint: "A long research document for a degree.",
    meaning: "An extended piece of research submitted for an academic degree.",
    fact: "The word originally meant simply 'a proposition put forward'.",
  },
  {
    word: "LECTURE",
    category: "education",
    hint: "One person talks, many take notes.",
    meaning: "An educational talk given to an audience of students.",
    fact: "Attention typically dips sharply after about 15 minutes.",
  },
  {
    word: "LIBRARY",
    category: "education",
    hint: "Quiet place, many books.",
    meaning: "A collection of books and resources available for use.",
    fact: "The Library of Alexandria aimed to collect every book in the world.",
  },
  {
    word: "SYLLABUS",
    category: "education",
    hint: "The outline of what a course will cover.",
    meaning: "A document listing the topics covered in a course.",
    fact: "The word entered use through a printing error in a Latin text.",
  },
  {
    word: "SCHOLARSHIP",
    category: "education",
    hint: "Financial help awarded for merit or need.",
    meaning: "A grant of money to support a student's education.",
    fact: "The oldest known ones date back to medieval European universities.",
  },
  {
    word: "GRADUATE",
    category: "education",
    hint: "Someone who has finished a degree.",
    meaning: "A person who has successfully completed a course of study.",
    fact: "The square graduation cap is called a mortarboard.",
  },
  {
    word: "CURRICULUM",
    category: "education",
    hint: "The full set of courses in a programme.",
    meaning: "The subjects and content taught in a school or programme.",
    fact: "The Latin root means 'a running course'.",
  },
  {
    word: "TUTORIAL",
    category: "education",
    hint: "A small-group session for practice.",
    meaning: "A session or guide giving focused instruction on a topic.",
    fact: "Oxford's one-to-one version dates back to the 1800s.",
  },
  {
    word: "SEMESTER",
    category: "education",
    hint: "Half an academic year.",
    meaning: "A half-year term in a school or university.",
    fact: "The name comes from Latin for 'six months'.",
  },
  ...EXTRA_WORDS,
];

export function difficultyOf(word: string): Difficulty {
  const n = word.replace(/[^A-Z]/g, "").length;
  if (n <= 5) return "easy";
  if (n <= 8) return "medium";
  return "hard";
}

export const DIFFICULTY_CONFIG: Record<
  Difficulty,
  { label: string; attempts: number; hints: number; multiplier: number; blurb: string }
> = {
  easy: { label: "Easy", attempts: 8, hints: 3, multiplier: 1, blurb: "Short words, 8 lives, 3 hints" },
  medium: {
    label: "Medium",
    attempts: 6,
    hints: 2,
    multiplier: 1.5,
    blurb: "Mid-length words, 6 lives, 2 hints",
  },
  hard: { label: "Hard", attempts: 5, hints: 1, multiplier: 2.25, blurb: "Long words, 5 lives, 1 hint" },
};

export function wordKey(entry: WordEntry) {
  return `${entry.category}:${entry.word}`;
}

export function findWord(key: string): WordEntry | undefined {
  return WORDS.find((w) => wordKey(w) === key);
}

/** Pick a random word matching filters, skipping already-used keys until the pool is exhausted. */
export function pickWord(
  category: CategoryId | "random",
  difficulty: Difficulty,
  usedKeys: string[],
): { entry: WordEntry; poolReset: boolean } {
  let pool = WORDS.filter(
    (w) =>
      (category === "random" || w.category === category) && difficultyOf(w.word) === difficulty,
  );
  if (pool.length === 0) {
    pool = WORDS.filter((w) => category === "random" || w.category === category);
  }
  if (pool.length === 0) pool = WORDS;

  const used = new Set(usedKeys);
  const fresh = pool.filter((w) => !used.has(wordKey(w)));
  const poolReset = fresh.length === 0;
  const source = poolReset ? pool : fresh;
  const entry = source[Math.floor(Math.random() * source.length)] ?? WORDS[0]!;
  return { entry, poolReset };
}
