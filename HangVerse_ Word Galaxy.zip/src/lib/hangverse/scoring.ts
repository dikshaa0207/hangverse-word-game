import { DIFFICULTY_CONFIG, type Difficulty } from "./words";

export const POINTS = {
  correctLetter: 10,
  wrongGuess: -5,
  hint: -15,
  winBase: 50,
  perAttemptLeft: 8,
};

export function scoreCorrectLetter(difficulty: Difficulty, occurrences: number) {
  return Math.round(POINTS.correctLetter * occurrences * DIFFICULTY_CONFIG[difficulty].multiplier);
}

export function winBonus(difficulty: Difficulty, attemptsLeft: number) {
  const m = DIFFICULTY_CONFIG[difficulty].multiplier;
  return Math.round((POINTS.winBase + attemptsLeft * POINTS.perAttemptLeft) * m);
}

export function coinsFor(result: "won" | "lost", difficulty: Difficulty, attemptsLeft: number) {
  if (result === "lost") return 5;
  const m = DIFFICULTY_CONFIG[difficulty].multiplier;
  return Math.round((15 + attemptsLeft * 3) * m);
}

export const WIN_MESSAGES = [
  "Amazing! You nailed it!",
  "Fantastic guessing!",
  "You're becoming a HangVerse master!",
  "Sharp mind — that word never stood a chance.",
];

export const LOSS_MESSAGES = [
  "So close! That word was a tough one.",
  "Every miss teaches you a new word. Try again!",
  "Don't stop now — the next one is yours.",
];

export function pickMessage(list: string[]) {
  return list[Math.floor(Math.random() * list.length)] ?? list[0]!;
}
