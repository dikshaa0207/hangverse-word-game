import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";
import { defaultState, loadState, saveState, type HangVerseState, type HistoryEntry } from "./storage";
import { evaluateAchievements } from "./achievements";

interface StoreValue {
  state: HangVerseState;
  hydrated: boolean;
  update: (patch: Partial<HangVerseState> | ((s: HangVerseState) => Partial<HangVerseState>)) => void;
  recordRound: (round: RoundResult) => { unlocked: string[] };
  resetProgress: () => void;
}

export interface RoundResult extends Omit<HistoryEntry, "id" | "playedAt"> {
  wordKey: string;
  coinsEarned: number;
}

const StoreContext = createContext<StoreValue | null>(null);

export function HangVerseProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<HangVerseState>(defaultState);
  const [hydrated, setHydrated] = useState(false);
  const hydratedRef = useRef(false);

  useEffect(() => {
    setState(loadState());
    hydratedRef.current = true;
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydratedRef.current) saveState(state);
  }, [state]);

  const update = useCallback<StoreValue["update"]>((patch) => {
    setState((prev) => ({ ...prev, ...(typeof patch === "function" ? patch(prev) : patch) }));
  }, []);

  const recordRound = useCallback<StoreValue["recordRound"]>((round) => {
    let unlocked: string[] = [];
    setState((prev) => {
      const won = round.result === "won";
      const currentStreak = won ? prev.currentStreak + 1 : 0;
      const entry: HistoryEntry = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        playedAt: Date.now(),
        word: round.word,
        category: round.category,
        difficulty: round.difficulty,
        result: round.result,
        score: round.score,
        hintsUsed: round.hintsUsed,
        wrongGuesses: round.wrongGuesses,
      };

      const next: HangVerseState = {
        ...prev,
        gamesPlayed: prev.gamesPlayed + 1,
        gamesWon: prev.gamesWon + (won ? 1 : 0),
        gamesLost: prev.gamesLost + (won ? 0 : 1),
        coins: prev.coins + round.coinsEarned,
        totalScore: prev.totalScore + round.score,
        bestScore: Math.max(prev.bestScore, round.score),
        currentStreak,
        bestStreak: Math.max(prev.bestStreak, currentStreak),
        totalHintsUsed: prev.totalHintsUsed + round.hintsUsed,
        perfectWins: prev.perfectWins + (won && round.wrongGuesses === 0 ? 1 : 0),
        hardWins: prev.hardWins + (won && round.difficulty === "hard" ? 1 : 0),
        usedWordKeys: prev.usedWordKeys.includes(round.wordKey)
          ? prev.usedWordKeys
          : [...prev.usedWordKeys, round.wordKey],
        discoveredKeys: prev.discoveredKeys.includes(round.wordKey)
          ? prev.discoveredKeys
          : [...prev.discoveredKeys, round.wordKey],
        categoriesPlayed: prev.categoriesPlayed.includes(round.category)
          ? prev.categoriesPlayed
          : [...prev.categoriesPlayed, round.category],
        history: [entry, ...prev.history].slice(0, 60),
      };

      unlocked = evaluateAchievements(next);
      if (unlocked.length) {
        const stamped = { ...next.achievements };
        unlocked.forEach((id) => (stamped[id] = Date.now()));
        next.achievements = stamped;
      }
      return next;
    });
    return { unlocked };
  }, []);

  const resetProgress = useCallback(() => setState({ ...defaultState }), []);

  const value = useMemo(
    () => ({ state, hydrated, update, recordRound, resetProgress }),
    [state, hydrated, update, recordRound, resetProgress],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useHangVerse() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useHangVerse must be used inside HangVerseProvider");
  return ctx;
}
