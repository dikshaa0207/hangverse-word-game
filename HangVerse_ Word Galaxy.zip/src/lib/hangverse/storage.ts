import type { CategoryId, Difficulty } from "./words";

export const STORAGE_KEY = "hangverse.save.v1";

export interface HistoryEntry {
  id: string;
  word: string;
  category: CategoryId;
  difficulty: Difficulty;
  result: "won" | "lost";
  score: number;
  hintsUsed: number;
  wrongGuesses: number;
  playedAt: number;
}

export interface HangVerseState {
  playerName: string;
  coins: number;
  bestScore: number;
  totalScore: number;
  gamesPlayed: number;
  gamesWon: number;
  gamesLost: number;
  currentStreak: number;
  bestStreak: number;
  totalHintsUsed: number;
  perfectWins: number;
  hardWins: number;
  usedWordKeys: string[];
  discoveredKeys: string[];
  categoriesPlayed: CategoryId[];
  achievements: Record<string, number>;
  history: HistoryEntry[];
  lastCategory: CategoryId | "random";
  lastDifficulty: Difficulty;
}

export const defaultState: HangVerseState = {
  playerName: "Player One",
  coins: 0,
  bestScore: 0,
  totalScore: 0,
  gamesPlayed: 0,
  gamesWon: 0,
  gamesLost: 0,
  currentStreak: 0,
  bestStreak: 0,
  totalHintsUsed: 0,
  perfectWins: 0,
  hardWins: 0,
  usedWordKeys: [],
  discoveredKeys: [],
  categoriesPlayed: [],
  achievements: {},
  history: [],
  lastCategory: "random",
  lastDifficulty: "easy",
};

export function loadState(): HangVerseState {
  if (typeof window === "undefined") return defaultState;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState;
    const parsed = JSON.parse(raw) as Partial<HangVerseState>;
    return {
      ...defaultState,
      ...parsed,
      usedWordKeys: parsed.usedWordKeys ?? [],
      discoveredKeys: parsed.discoveredKeys ?? [],
      categoriesPlayed: parsed.categoriesPlayed ?? [],
      achievements: parsed.achievements ?? {},
      history: parsed.history ?? [],
    };
  } catch {
    return defaultState;
  }
}

export function saveState(state: HangVerseState) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* storage full or unavailable — game still playable in-memory */
  }
}
