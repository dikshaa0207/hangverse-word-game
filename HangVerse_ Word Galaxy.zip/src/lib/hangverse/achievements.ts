import type { HangVerseState } from "./storage";

export interface Achievement {
  id: string;
  name: string;
  description: string;
  emoji: string;
  check: (s: HangVerseState) => boolean;
}

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: "first-win",
    name: "First Win",
    description: "Win your very first round of HangVerse.",
    emoji: "🌟",
    check: (s) => s.gamesWon >= 1,
  },
  {
    id: "five-wins",
    name: "5 Wins",
    description: "Win five rounds in total.",
    emoji: "🖐️",
    check: (s) => s.gamesWon >= 5,
  },
  {
    id: "ten-wins",
    name: "10 Wins",
    description: "Win ten rounds in total.",
    emoji: "🏆",
    check: (s) => s.gamesWon >= 10,
  },
  {
    id: "word-master",
    name: "Word Master",
    description: "Discover 20 different words.",
    emoji: "📚",
    check: (s) => s.discoveredKeys.length >= 20,
  },
  {
    id: "perfect-guess",
    name: "Perfect Guess",
    description: "Win a round without a single wrong letter.",
    emoji: "🎯",
    check: (s) => s.perfectWins >= 1,
  },
  {
    id: "hint-master",
    name: "Hint Master",
    description: "Win 3 rounds without ever using a hint.",
    emoji: "🧠",
    check: (s) =>
      s.history.filter((h) => h.result === "won" && h.hintsUsed === 0).length >= 3,
  },
  {
    id: "category-explorer",
    name: "Category Explorer",
    description: "Play words from 5 different categories.",
    emoji: "🧭",
    check: (s) => s.categoriesPlayed.length >= 5,
  },
  {
    id: "hard-mode-champion",
    name: "Hard Mode Champion",
    description: "Win 3 rounds on Hard difficulty.",
    emoji: "🔥",
    check: (s) => s.hardWins >= 3,
  },
  {
    id: "streak-runner",
    name: "Streak Runner",
    description: "Reach a winning streak of 5.",
    emoji: "⚡",
    check: (s) => s.bestStreak >= 5,
  },
  {
    id: "coin-collector",
    name: "Coin Collector",
    description: "Earn 500 coins in total.",
    emoji: "🪙",
    check: (s) => s.coins >= 500,
  },
];

export function evaluateAchievements(state: HangVerseState): string[] {
  return ACHIEVEMENTS.filter((a) => !state.achievements[a.id] && a.check(state)).map((a) => a.id);
}

export function achievementById(id: string) {
  return ACHIEVEMENTS.find((a) => a.id === id);
}
